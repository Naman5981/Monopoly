/**
 * ui/anim.js
 * High-performance Anime.js animation orchestration module.
 * Adheres to `animejs-animation`, `better-ui`, and `fixing-motion-performance`:
 * Uses spring physics, staggered rhythms, GPU transforms, and respects prefers-reduced-motion.
 */

export function isReducedMotion() {
  return typeof window !== 'undefined' &&
    window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/**
 * Orchestrates arcade staggered entrance on title / lobby setup arena.
 */
export function animateLobbyEntrance() {
  if (typeof anime === 'undefined' || isReducedMotion()) return;

  const tl = anime.timeline({
    easing: 'easeOutQuad'
  });

  // 1. Studio Header drops down
  tl.add({
    targets: '#landing-setup-screen > div:first-child',
    translateY: [-24, 0],
    opacity: [0, 1],
    duration: 380
  })
  // 2. 3D Hero Centerpiece bouncy spring entrance
  .add({
    targets: '#lobby-hero-column',
    scale: [0.86, 1],
    opacity: [0, 1],
    duration: 650,
    easing: 'spring(1, 80, 11, 0)'
  }, '-=250')
  // 3. Table roster cards slide and pop from left
  .add({
    targets: '#setup-players-roster > div',
    translateX: [-30, 0],
    opacity: [0, 1],
    delay: anime.stagger(45),
    duration: 420,
    easing: 'easeOutBack'
  }, '-=400')
  // 4. Match settings Bento items slide from right
  .add({
    targets: '#lobby-settings-column .space-y-4 > div',
    translateX: [30, 0],
    opacity: [0, 1],
    delay: anime.stagger(50),
    duration: 420,
    easing: 'easeOutBack'
  }, '-=350');
}

/**
 * Staggers wardrobe item cards when opening or switching category tabs.
 * @param {string} gridSelector - Default '#wardrobe-items-grid > div'
 */
export function animateWardrobeGridCascade(gridSelector = '#wardrobe-items-grid > div') {
  if (typeof anime === 'undefined' || isReducedMotion()) return;

  const cards = document.querySelectorAll(gridSelector);
  if (!cards.length) return;

  anime.remove(cards);
  anime({
    targets: cards,
    translateY: [24, 0],
    scale: [0.94, 1],
    opacity: [0, 1],
    delay: anime.stagger(30),
    duration: 380,
    easing: 'cubicBezier(0.2, 0, 0, 1)'
  });
}

/**
 * Interpolates numeric counters (Cash, Stars, Rent) with an odometer rolling effect.
 * @param {HTMLElement} element - Target DOM node
 * @param {number} startVal - Initial number
 * @param {number} endVal - Final target number
 * @param {string} prefix - Currency prefix e.g. '$' or '⭐'
 * @param {string} suffix - e.g. ' ⭐'
 * @param {number} duration - Animation duration in ms
 */
export function animateNumberCounter(element, startVal, endVal, prefix = '', suffix = '', duration = 650) {
  if (!element) return;
  const targetNum = Number(endVal) || 0;
  const initialNum = Number(startVal) || 0;

  if (typeof anime === 'undefined' || isReducedMotion() || Math.abs(targetNum - initialNum) < 2) {
    element.textContent = `${prefix}${targetNum.toLocaleString()}${suffix}`;
    return;
  }

  const obj = { val: initialNum };
  anime.remove(obj);
  anime({
    targets: obj,
    val: targetNum,
    round: 1,
    duration,
    easing: 'easeOutExpo',
    update: () => {
      element.textContent = `${prefix}${Math.round(obj.val).toLocaleString()}${suffix}`;
    }
  });
}

/**
 * Dynamic spring punch-in for game modals (Buy City, Inspector, Chance, Victory).
 * @param {string|HTMLElement} target - Modal shell selector or element
 */
export function animateModalPunchIn(target) {
  if (typeof anime === 'undefined' || isReducedMotion()) return;
  const el = typeof target === 'string' ? document.querySelector(target) : target;
  if (!el) return;

  anime.remove(el);
  anime({
    targets: el,
    scale: [0.82, 1],
    opacity: [0, 1],
    duration: 480,
    easing: 'spring(1, 80, 11, 0)'
  });
}

/**
 * Animated tally reveal for match victory rewards breakdown.
 * @param {string} containerSelector - Selector for breakdown container
 */
export function animateVictoryTally(containerSelector = '#victory-breakdown-list > div') {
  if (typeof anime === 'undefined' || isReducedMotion()) return;
  const items = document.querySelectorAll(containerSelector);
  if (!items.length) return;

  anime.remove(items);
  anime({
    targets: items,
    translateX: [36, 0],
    opacity: [0, 1],
    delay: anime.stagger(80),
    duration: 450,
    easing: 'easeOutBack'
  });
}
