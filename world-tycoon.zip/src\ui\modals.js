/**
 * ui/modals.js
 * Modals management: Buy City, Live Auction, Chance Wheel, Inspector, Portfolio, Trade, Lobby, Rules, Victory.
 */

import { BOARD_TILES, GROUP_META, PLAYER_THEMES, CHANCE_WHEEL_PRIZES } from '../game/data.js';
import { gameState, isHumanTurnActionable, setLobbyPlayerCount, lobbyPlayerCount, displayedCash, localPlayerIdx } from '../game/state.js';
import { fmtMoney } from '../game/utils.js';
import { playSFX } from '../game/audio.js';
import { calculateTileRent, ownsFullColorGroup, checkVictoryConditions, calculatePlayerNetWorth, countCompletedColorGroups, checkLineMonopoly } from '../game/rules.js';
import { networkState, broadcastAction, broadcastReturnToLobby, broadcastStartOnlineMatch } from '../network/p2p.js';
import { matchSettings } from '../game/state.js';
import {
  populateCityPreview3DScene,
  clearCityPreview,
  setTileHighlightRing,
  showSpeechBubble,
  refreshTileTextureAndBuildings,
  getTileWorldPosition,
  setMonopolyTileHighlights,
  startIntroCameraFlyIn
} from '../three/scene.js';
import { renderCornerHUDs, showTurnLockToast, logEvent, setStatusPill, refreshActivePlayerTurnStatus } from './hud.js';
import { fireConfettiBurst, spawnAnimatedReaction, startVictoryCelebration, stopVictoryCelebration } from '../three/effects.js';
import { saveCurrentMatchToStorage, clearSavedMatch } from '../game/persistence.js';
import { evaluateTradeDeal, generateProactiveBotTrade } from '../game/trading.js';

let engineCallbacks = {};

export function registerEngineCallbacks(cbs) {
  engineCallbacks = cbs;
}

export function isLobbyScreenActive() {
  if (!gameState.gameStarted || gameState.phase === 'SETUP') return true;
  const landingScreen = document.getElementById('landing-setup-screen');
  return !!(landingScreen && !landingScreen.classList.contains('hidden') && landingScreen.style.display !== 'none');
}

export function getTierBadgeHTML(level) {
  if (level === 0) {
    return `<div class="tier-level-badge tier-house"><span class="text-xs">🚩</span><span class="text-[11px] font-black text-emerald-800">Base</span></div>`;
  }
  if (level === 4) {
    return `<div class="tier-level-badge tier-skyscraper-badge"><span class="text-xs">🏙️</span><span class="text-[10px] font-black text-amber-900 tracking-tight">MAX</span></div>`;
  }
  return `<div class="tier-level-badge tier-house"><span class="text-xs">🏠</span><span class="text-[11px] font-black text-emerald-800">${level}</span></div>`;
}

/* ─────────────────────────────────────────────────────────────────────────────
   A. BUY CITY MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openBuyCityModal(tile, isDoubles) {
  if (isLobbyScreenActive()) return;
  gameState.phase = 'MODAL';
  gameState.pendingBuyTile = tile;
  gameState.pendingDoubles = isDoubles;
  if (engineCallbacks.updateUI) engineCallbacks.updateUI();

  const pos = getTileWorldPosition(tile.id);
  setTileHighlightRing(tile.id, true);
  setStatusPill(`🏢 Deciding whether to buy <strong>${tile.name}</strong> (${fmtMoney(tile.price)})...`, { isThinking: false, playerIdx: gameState.currentPlayerIdx });

  const header = document.getElementById('buy-modal-header');
  header.style.background = tile.group ? GROUP_META[tile.group].hex : '#0284c7';
  document.getElementById('buy-modal-country').textContent = tile.group ? GROUP_META[tile.group].name : 'RESORT DESTINATION';
  document.getElementById('buy-modal-name').textContent = tile.name;
  document.getElementById('buy-modal-price').textContent = fmtMoney(tile.price);
  document.getElementById('buy-modal-rent').textContent = fmtMoney(tile.rent[0]);

  const tiers = document.getElementById('buy-modal-tiers');
  if (tile.type === 'city') {
    tiers.innerHTML = `
      <div class="game-tier-card">
        <div class="flex items-center gap-2.5">
          ${getTierBadgeHTML(1)}
          <div>
            <div class="font-display font-black text-xs sm:text-sm text-slate-800 leading-tight">1 House</div>
            <div class="text-[10px] text-slate-400 font-bold">Standard Estate</div>
          </div>
        </div>
        <div class="tier-val-pill">${fmtMoney(tile.rent[1])}</div>
      </div>
      <div class="game-tier-card">
        <div class="flex items-center gap-2.5">
          ${getTierBadgeHTML(2)}
          <div>
            <div class="font-display font-black text-xs sm:text-sm text-slate-800 leading-tight">2 Houses</div>
            <div class="text-[10px] text-slate-400 font-bold">Expanded District</div>
          </div>
        </div>
        <div class="tier-val-pill">${fmtMoney(tile.rent[2])}</div>
      </div>
      <div class="game-tier-card">
        <div class="flex items-center gap-2.5">
          ${getTierBadgeHTML(3)}
          <div>
            <div class="font-display font-black text-xs sm:text-sm text-slate-800 leading-tight">3 Houses</div>
            <div class="text-[10px] text-slate-400 font-bold">Prime Plaza</div>
          </div>
        </div>
        <div class="tier-val-pill">${fmtMoney(tile.rent[3])}</div>
      </div>
      <div class="game-tier-card tier-card-skyscraper">
        <div class="flex items-center gap-2.5">
          ${getTierBadgeHTML(4)}
          <div>
            <div class="font-display font-black text-xs sm:text-sm text-amber-950 flex items-center gap-1.5 leading-tight">
              <span>Skyscraper</span>
              <span class="text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md bg-amber-400 text-amber-950 border border-amber-500/50 shadow-2xs">MAX</span>
            </div>
            <div class="text-[10px] text-amber-800/80 font-bold">Global Megatower</div>
          </div>
        </div>
        <div class="tier-val-pill tier-val-skyscraper">
          <i class="fa-solid fa-bolt text-amber-600 text-xs mr-0.5"></i>${fmtMoney(tile.rent[4])}
        </div>
      </div>
    `;
  } else {
    tiers.innerHTML = `
      <div class="p-3 bg-gradient-to-r from-sky-50 to-indigo-50 rounded-2xl border-2 border-sky-200 text-center space-y-1">
        <div class="text-xl">🌴 🏖️</div>
        <div class="font-display font-black text-xs sm:text-sm text-sky-950">Luxury Destination Resort</div>
        <div class="text-[11px] text-slate-600 font-bold">Collect 2× boosted payouts when owning both world resorts!</div>
      </div>
    `;
  }

  const pIdx = gameState.currentPlayerIdx;
  const p = gameState.players[pIdx] || gameState.players[0];
  const btnBuy = document.getElementById('btn-confirm-buy');
  const canAfford = p && p.cash >= tile.price;
  btnBuy.disabled = !canAfford;
  btnBuy.innerHTML = canAfford
    ? `<i class="fa-solid fa-cart-shopping mr-1"></i> BUY CITY`
    : `<i class="fa-solid fa-lock mr-1"></i> NEED ${fmtMoney(tile.price)}`;
  btnBuy.className = `game-btn ${canAfford ? 'game-btn-green' : 'game-btn-slate opacity-50 cursor-not-allowed'} flex-1 py-3.5 text-sm font-black`;

  populateCityPreview3DScene(tile, 'buy-city-3d-canvas');

  const m = document.getElementById('modal-buy-city');
  const card = document.getElementById('modal-buy-city-card');
  m.classList.remove('hidden');
  m.classList.add('flex', 'city-modal-backdrop-enter');
  if (card) {
    card.classList.remove('city-modal-card-exit', 'city-modal-card-enter');
    void card.offsetWidth;
    card.classList.add('city-modal-card-enter');
  }
  playSFX('hop');
}

export function confirmBuyCity() {
  const tile = gameState.pendingBuyTile;
  const pIdx = gameState.currentPlayerIdx;
  const p = gameState.players[pIdx];
  if (!tile || !p || p.cash < tile.price) return;

  p.cash -= tile.price;
  gameState.properties[tile.id].owner = pIdx;
  playSFX('build');
  fireConfettiBurst(window.innerWidth / 2, window.innerHeight * 0.4, 45);
  spawnAnimatedReaction('money', window.innerWidth / 2, window.innerHeight * 0.4);
  if (engineCallbacks.spawnFloatingCash) engineCallbacks.spawnFloatingCash(pIdx, `-${fmtMoney(tile.price)}`, false);
  logEvent(`🏙️ <strong>${p.name}</strong> bought <strong>${tile.name}</strong> for <strong>${fmtMoney(tile.price)}</strong>!`);

  if (networkState.isMultiplayer) {
    broadcastAction('ACTION_BUY_CITY', { playerIdx: pIdx, tileId: tile.id });
  }

  clearCityPreview();
  document.getElementById('modal-buy-city').classList.add('hidden');
  document.getElementById('modal-buy-city').classList.remove('flex');
  refreshTileTextureAndBuildings(tile.id);
  renderCornerHUDs();
  if (tile.group) {
    checkAndTriggerMonopoly(pIdx, tile.group);
  }
  if (engineCallbacks.concludeActionPhase) {
    engineCallbacks.concludeActionPhase(gameState.pendingDoubles);
  }
}

export function passBuyCity() {
  const tile = gameState.pendingBuyTile;
  if (tile) {
    setTileHighlightRing(tile.id, false);
    const p = gameState.players[gameState.currentPlayerIdx];
    if (p) logEvent(`🏷️ <strong>${p.name}</strong> passed on buying <strong>${tile.name}</strong>.`);
  }
  clearCityPreview();
  const m = document.getElementById('modal-buy-city');
  if (m) {
    m.classList.add('hidden');
    m.classList.remove('flex');
  }
  gameState.pendingBuyTile = null;

  if (engineCallbacks.concludeActionPhase) {
    engineCallbacks.concludeActionPhase(gameState.pendingDoubles);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   A2. UPGRADE CITY POPUP MODAL (When landing on owned property)
───────────────────────────────────────────────────────────────────────────── */
export function openUpgradeCityModal(tile, isDoubles) {
  if (isLobbyScreenActive()) return;
  gameState.phase = 'MODAL';
  gameState.pendingUpgradeTile = tile;
  gameState.pendingDoubles = isDoubles;
  gameState.upgradesThisVisit = 0;
  if (engineCallbacks.updateUI) engineCallbacks.updateUI();

  setTileHighlightRing(tile.id, true);
  setStatusPill(`🏗️ Managing property upgrades for <strong>${tile.name}</strong>...`, { isThinking: false, playerIdx: gameState.currentPlayerIdx });
  renderUpgradeModalContent(tile);
  populateCityPreview3DScene(tile, 'upgrade-city-3d-canvas');

  const m = document.getElementById('modal-upgrade-city');
  const card = document.getElementById('modal-upgrade-city-card');
  m.classList.remove('hidden');
  m.classList.add('flex', 'city-modal-backdrop-enter');
  if (card) {
    card.classList.remove('city-modal-card-exit', 'city-modal-card-enter');
    void card.offsetWidth;
    card.classList.add('city-modal-card-enter');
  }
  playSFX('hop');
}

export function renderUpgradeModalContent(tile) {
  const st = gameState.properties[tile.id];
  if (!st) return;
  const pIdx = gameState.currentPlayerIdx;
  const p = gameState.players[pIdx] || gameState.players[0];

  const header = document.getElementById('upgrade-modal-header');
  const groupColor = tile.group ? GROUP_META[tile.group].hex : '#10b981';
  header.style.background = groupColor;

  document.getElementById('upgrade-modal-country').innerHTML = `
    <i class="fa-solid fa-crown text-amber-300"></i> ${tile.group ? GROUP_META[tile.group].name : 'ESTATE'}
  `;

  const levelLabels = ['Base', '1 House', '2 Houses', '3 Houses', 'Skyscraper'];
  const levelPill = document.getElementById('upgrade-modal-level-pill');
  if (st.mortgaged) {
    levelPill.textContent = 'MORTGAGED';
    levelPill.className = 'text-xs font-black px-2.5 py-1 rounded-full bg-rose-600/90 border border-white/40 shadow-xs';
  } else {
    levelPill.textContent = `Level ${st.level}: ${levelLabels[st.level] || 'Base'}`;
    levelPill.className = 'text-xs font-black px-2.5 py-1 rounded-full bg-white/25 border border-white/40 shadow-xs';
  }

  document.getElementById('upgrade-modal-name').textContent = tile.name;

  const curRent = calculateTileRent(tile.id);
  document.getElementById('upgrade-modal-current-rent').textContent = fmtMoney(curRent);
  document.getElementById('upgrade-modal-cost').textContent = fmtMoney(tile.houseCost);
  document.getElementById('upgrade-modal-balance').textContent = `Balance: ${fmtMoney(p.cash)}`;

  // Tiers breakdown
  const tiersEl = document.getElementById('upgrade-modal-tiers');
  tiersEl.innerHTML = levelLabels.map((lbl, idx) => {
    const isCurrent = (st.level === idx && !st.mortgaged);
    const isNext = (st.level + 1 === idx && !st.mortgaged);
    const rentVal = tile.rent[idx];
    const isSky = (idx === 4);

    let cardClass = isCurrent
      ? 'game-tier-card tier-card-current'
      : (isNext ? 'game-tier-card tier-card-next' : (isSky ? 'game-tier-card tier-card-skyscraper' : 'game-tier-card'));

    let statusPill = '';
    if (isCurrent) {
      statusPill = '<span class="text-[9px] uppercase px-2 py-0.5 rounded-full bg-emerald-600 text-white font-black shadow-2xs">ACTIVE</span>';
    } else if (isNext) {
      statusPill = '<span class="text-[9px] uppercase px-2 py-0.5 rounded-full bg-sky-500 text-white font-black shadow-2xs">+NEXT</span>';
    } else if (isSky) {
      statusPill = '<span class="text-[9px] uppercase px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 font-black shadow-2xs">MAX</span>';
    }

    let valPillClass = isCurrent
      ? 'tier-val-pill bg-emerald-600 text-white border-emerald-500 shadow-xs'
      : (isSky ? 'tier-val-pill tier-val-skyscraper' : 'tier-val-pill');

    return `
      <div class="${cardClass}">
        <div class="flex items-center gap-2.5">
          ${getTierBadgeHTML(idx)}
          <div>
            <div class="font-display font-black text-xs sm:text-sm text-slate-800 flex items-center gap-1.5 leading-tight">
              <span>${lbl}</span>
              ${statusPill}
            </div>
            <div class="text-[10px] text-slate-400 font-bold">${idx === 0 ? 'Base Land Payout' : (isSky ? 'Maximum Empire Rent' : `District Level ${idx}`)}</div>
          </div>
        </div>
        <div class="${valPillClass}">${fmtMoney(rentVal)}</div>
      </div>
    `;
  }).join('');

  // Status Notice & Upgrade button states
  const noticeEl = document.getElementById('upgrade-modal-notice');
  const btnUpgrade = document.getElementById('btn-confirm-upgrade');
  const btnUpgrade2 = document.getElementById('btn-confirm-upgrade-2');
  const btnClose = document.getElementById('btn-close-upgrade-modal');
  const upgradesDone = gameState.upgradesThisVisit || 0;

  if (st.mortgaged) {
    if (btnUpgrade2) btnUpgrade2.classList.add('hidden');
    const unmortCost = Math.round(tile.price * 0.55);
    const canUnmort = p.cash >= unmortCost;
    noticeEl.classList.remove('hidden');
    noticeEl.innerHTML = `<i class="fa-solid fa-triangle-exclamation text-amber-600 mr-1"></i> City is mortgaged! Unmortgage to start collecting rent and upgrading.`;
    btnUpgrade.disabled = !canUnmort;
    btnUpgrade.className = `game-btn ${canUnmort ? 'game-btn-blue' : 'game-btn-slate opacity-50 cursor-not-allowed'} flex-1 py-3 px-3 text-xs sm:text-sm font-black flex flex-col items-center justify-center gap-0.5 leading-snug`;
    btnUpgrade.innerHTML = `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-key"></i> UNMORTGAGE</span><span class="text-xs font-bold opacity-90">(${fmtMoney(unmortCost)})</span>`;
    btnClose.textContent = 'CLOSE';
  } else if (upgradesDone >= 2) {
    if (btnUpgrade2) btnUpgrade2.classList.add('hidden');
    noticeEl.classList.remove('hidden');
    noticeEl.innerHTML = `<i class="fa-solid fa-circle-check text-emerald-600 mr-1"></i> <strong class="text-emerald-800">Visit Limit Reached (2/2)!</strong> You can upgrade at most 2 levels at one time.`;
    btnUpgrade.disabled = true;
    btnUpgrade.className = 'game-btn game-btn-slate opacity-50 cursor-not-allowed flex-1 py-3 px-3 text-xs sm:text-sm font-black flex flex-col items-center justify-center gap-0.5 leading-snug';
    btnUpgrade.innerHTML = `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-ban text-amber-500"></i> MAX REACHED</span><span class="text-xs font-bold opacity-80">(2/2 Levels)</span>`;
    btnClose.textContent = 'DONE';
  } else if (st.level >= 4) {
    if (btnUpgrade2) btnUpgrade2.classList.add('hidden');
    noticeEl.classList.remove('hidden');
    noticeEl.innerHTML = `🏆 <strong class="text-amber-800">Skyscraper Maxed!</strong> This estate is generating maximum rent of ${fmtMoney(tile.rent[4])}.`;
    btnUpgrade.disabled = true;
    btnUpgrade.className = 'game-btn game-btn-slate opacity-50 cursor-not-allowed flex-1 py-3 px-3 text-xs sm:text-sm font-black flex flex-col items-center justify-center gap-0.5 leading-snug';
    btnUpgrade.innerHTML = `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-crown text-amber-500"></i> MAX LEVEL</span><span class="text-xs font-bold opacity-80">(Skyscraper)</span>`;
    btnClose.textContent = 'DONE';
  } else {
    const canAfford = p.cash >= tile.houseCost;
    btnUpgrade.disabled = !canAfford;
    btnUpgrade.className = `game-btn ${canAfford ? 'game-btn-green' : 'game-btn-slate opacity-50 cursor-not-allowed'} flex-1 py-3 px-3 text-xs sm:text-sm font-black flex flex-col items-center justify-center gap-0.5 leading-snug`;
    btnUpgrade.innerHTML = canAfford
      ? `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-arrow-up-right-dots"></i> +1 LEVEL</span><span class="text-xs font-bold opacity-90">(${fmtMoney(tile.houseCost)})</span>`
      : `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-lock"></i> +1 LEVEL</span><span class="text-xs font-bold opacity-80">(NEED ${fmtMoney(tile.houseCost)})</span>`;

    // Show +2 Levels button if 0 upgrades done yet, property can take 2 more levels, and level <= 2
    if (btnUpgrade2) {
      if (upgradesDone === 0 && st.level <= 2) {
        btnUpgrade2.classList.remove('hidden');
        const cost2 = tile.houseCost * 2;
        const canAfford2 = p.cash >= cost2;
        btnUpgrade2.disabled = !canAfford2;
        btnUpgrade2.className = `game-btn ${canAfford2 ? 'game-btn-blue' : 'game-btn-slate opacity-50 cursor-not-allowed'} flex-1 py-3 px-3 text-xs sm:text-sm font-black flex flex-col items-center justify-center gap-0.5 leading-snug`;
        btnUpgrade2.innerHTML = canAfford2
          ? `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-angles-up"></i> +2 LEVELS</span><span class="text-xs font-bold opacity-90">(${fmtMoney(cost2)})</span>`
          : `<span class="flex items-center justify-center gap-1.5"><i class="fa-solid fa-lock"></i> +2 LEVELS</span><span class="text-xs font-bold opacity-80">(NEED ${fmtMoney(cost2)})</span>`;
      } else {
        btnUpgrade2.classList.add('hidden');
      }
    }

    if (upgradesDone > 0) {
      noticeEl.classList.remove('hidden');
      noticeEl.innerHTML = `⭐ <strong>${upgradesDone}/2 Upgrades completed</strong> this visit. You may upgrade 1 more level.`;
      btnClose.textContent = 'DONE';
    } else {
      noticeEl.classList.add('hidden');
      if (st.level > 0) {
        btnClose.textContent = 'DONE';
      } else {
        btnClose.textContent = 'CONTINUE';
      }
    }
  }
}

export function confirmUpgradeFromModal() {
  const tile = gameState.pendingUpgradeTile;
  if (!tile) return;
  const st = gameState.properties[tile.id];
  const pIdx = gameState.currentPlayerIdx;
  const p = gameState.players[pIdx];
  if (!st || !p) return;

  if (st.mortgaged) {
    const unmortCost = Math.round(tile.price * 0.55);
    if (p.cash < unmortCost) return;
    p.cash -= unmortCost;
    st.mortgaged = false;
    playSFX('cash');
    logEvent(`🏦 <strong>${p.name}</strong> unmortgaged <strong>${tile.name}</strong>.`);
    refreshTileTextureAndBuildings(tile.id);
    renderCornerHUDs();
    renderUpgradeModalContent(tile);
    populateCityPreview3DScene(tile, 'upgrade-city-3d-canvas');
    return;
  }

  if ((gameState.upgradesThisVisit || 0) >= 2) {
    showTurnLockToast("You can only upgrade at most 2 levels at one time!");
    return;
  }

  if (st.level >= 4 || p.cash < tile.houseCost) return;

  upgradeCityLevel(tile.id, true);
  gameState.upgradesThisVisit = (gameState.upgradesThisVisit || 0) + 1;
  fireConfettiBurst(window.innerWidth / 2, window.innerHeight * 0.4, 40);
  spawnAnimatedReaction('star', window.innerWidth / 2, window.innerHeight * 0.4);

  // Re-render modal content with new level, rent, and 3D preview
  renderUpgradeModalContent(tile);
  populateCityPreview3DScene(tile, 'upgrade-city-3d-canvas');
}

export function confirmUpgradeTwoLevelsFromModal() {
  const tile = gameState.pendingUpgradeTile;
  if (!tile) return;
  const st = gameState.properties[tile.id];
  const pIdx = gameState.currentPlayerIdx;
  const p = gameState.players[pIdx];
  if (!st || !p || st.mortgaged) return;

  const cost2 = tile.houseCost * 2;
  if ((gameState.upgradesThisVisit || 0) > 0 || st.level > 2 || p.cash < cost2) return;

  upgradeCityLevel(tile.id, true);
  upgradeCityLevel(tile.id, true);
  gameState.upgradesThisVisit = 2;
  fireConfettiBurst(window.innerWidth / 2, window.innerHeight * 0.4, 55);
  spawnAnimatedReaction('star', window.innerWidth / 2, window.innerHeight * 0.4);

  renderUpgradeModalContent(tile);
  populateCityPreview3DScene(tile, 'upgrade-city-3d-canvas');
}

export function closeUpgradeCityModal() {
  const tile = gameState.pendingUpgradeTile;
  if (tile) {
    setTileHighlightRing(tile.id, false);
  }
  clearCityPreview();
  const m = document.getElementById('modal-upgrade-city');
  if (m) {
    m.classList.add('hidden');
    m.classList.remove('flex');
  }
  gameState.pendingUpgradeTile = null;

  if (engineCallbacks.concludeActionPhase) {
    engineCallbacks.concludeActionPhase(gameState.pendingDoubles);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   B. LIVE AUCTION MODAL
───────────────────────────────────────────────────────────────────────────── */
export function startCityAuction() {
  if (isLobbyScreenActive()) return;
  clearCityPreview();
  document.getElementById('modal-buy-city').classList.add('hidden');
  document.getElementById('modal-buy-city').classList.remove('flex');

  const tile = gameState.pendingBuyTile;
  const activeBidders = gameState.players.map((p, idx) => (!p.bankrupt ? idx : -1)).filter(i => i !== -1);

  gameState.auction = {
    tile,
    highBid: Math.max(50000, Math.round((tile.price * 0.4) / 25000) * 25000),
    highBidder: 0,
    activeBidders,
    turnPos: 0
  };

  updateAuctionModalUI();
  const m = document.getElementById('modal-auction');
  m.classList.remove('hidden');
  m.classList.add('flex');
  checkAIAuctionTurn();
}

export function updateAuctionModalUI() {
  const a = gameState.auction;
  if (!a) return;
  document.getElementById('auction-city-name').textContent = `Bidding on ${a.tile.name}`;
  document.getElementById('auction-base-val').textContent = `Value: ${fmtMoney(a.tile.price)}`;
  document.getElementById('auction-high-bid').textContent = fmtMoney(a.highBid);
  document.getElementById('auction-high-bidder').textContent = `Leading: ${gameState.players[a.highBidder]?.name}`;
  const curBidderIdx = a.activeBidders[a.turnPos % a.activeBidders.length];
  document.getElementById('auction-turn-player').textContent = gameState.players[curBidderIdx]?.name || 'Unknown';
}

export function placeAuctionBid(increment) {
  const a = gameState.auction;
  if (!a) return;
  const curBidderIdx = a.activeBidders[a.turnPos % a.activeBidders.length];
  const bidder = gameState.players[curBidderIdx];
  if (bidder.cash < a.highBid + increment) {
    passAuctionBid();
    return;
  }
  a.highBid += increment;
  a.highBidder = curBidderIdx;
  a.turnPos = (a.turnPos + 1) % a.activeBidders.length;
  playSFX('hop');
  updateAuctionModalUI();
  checkAIAuctionTurn();
}

export function passAuctionBid() {
  const a = gameState.auction;
  if (!a) return;
  const curPos = a.turnPos % a.activeBidders.length;
  a.activeBidders.splice(curPos, 1);

  if (a.activeBidders.length <= 1) {
    const winnerIdx = a.activeBidders[0] !== undefined ? a.activeBidders[0] : a.highBidder;
    const winner = gameState.players[winnerIdx];
    winner.cash -= a.highBid;
    gameState.properties[a.tile.id].owner = winnerIdx;
    playSFX('gavel');
    fireConfettiBurst(window.innerWidth / 2, window.innerHeight * 0.45, 50);
    if (engineCallbacks.spawnFloatingCash) engineCallbacks.spawnFloatingCash(winnerIdx, `-${fmtMoney(a.highBid)}`, false);
    logEvent(`🔨 <strong>${winner.name}</strong> won the auction for <strong>${a.tile.name}</strong> at <strong>${fmtMoney(a.highBid)}</strong>!`);

    document.getElementById('modal-auction').classList.add('hidden');
    document.getElementById('modal-auction').classList.remove('flex');
    refreshTileTextureAndBuildings(a.tile.id);
    renderCornerHUDs();
    if (a.tile.group) {
      checkAndTriggerMonopoly(winnerIdx, a.tile.group);
    }
    gameState.auction = null;
    if (engineCallbacks.concludeActionPhase) {
      engineCallbacks.concludeActionPhase(gameState.pendingDoubles);
    }
    return;
  }

  a.turnPos = a.turnPos % a.activeBidders.length;
  updateAuctionModalUI();
  checkAIAuctionTurn();
}

function checkAIAuctionTurn() {
  const a = gameState.auction;
  if (!a) return;
  const curBidderIdx = a.activeBidders[a.turnPos % a.activeBidders.length];
  const p = gameState.players[curBidderIdx];
  if (p && p.isAI) {
    setTimeout(() => {
      if (!gameState.auction) return;
      if (a.highBid + 25000 <= a.tile.price * 0.9 && p.cash >= a.highBid + 150000) {
        placeAuctionBid(25000);
      } else {
        passAuctionBid();
      }
    }, 550);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   C. CHANCE WHEEL MODAL
───────────────────────────────────────────────────────────────────────────── */
let wheelAngle = 0;

export function drawChanceWheelCanvas() {
  const c = document.getElementById('chance-wheel-canvas');
  if (!c) return;
  const ctx = c.getContext('2d');
  const cx = 320, cy = 320, outerR = 312;
  const rimWidth = 24;
  const innerR = outerR - rimWidth;
  const N = CHANCE_WHEEL_PRIZES.length;
  const slice = (Math.PI * 2) / N;

  ctx.clearRect(0, 0, 640, 640);

  // 1. Casino Gold Outer Rim
  const rimGrad = ctx.createRadialGradient(cx, cy, innerR, cx, cy, outerR);
  rimGrad.addColorStop(0, '#d97706');
  rimGrad.addColorStop(0.25, '#fef08a');
  rimGrad.addColorStop(0.6, '#f59e0b');
  rimGrad.addColorStop(1, '#78350f');
  ctx.beginPath();
  ctx.arc(cx, cy, outerR, 0, Math.PI * 2);
  ctx.fillStyle = rimGrad;
  ctx.fill();

  // Draw 24 golden carnival bulbs around the rim
  const bulbCount = 24;
  const bulbR = innerR + rimWidth / 2;
  for (let b = 0; b < bulbCount; b++) {
    const angle = (b * Math.PI * 2) / bulbCount;
    const bx = cx + Math.cos(angle) * bulbR;
    const by = cy + Math.sin(angle) * bulbR;
    ctx.beginPath();
    ctx.arc(bx, by, 5.5, 0, Math.PI * 2);
    ctx.fillStyle = b % 2 === 0 ? '#ffffff' : '#fef08a';
    ctx.fill();
    ctx.strokeStyle = '#92400e';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  const hubR = 50;

  // 2. Wheel Slices (Centered with Slice 0 at 12 o'clock)
  CHANCE_WHEEL_PRIZES.forEach((p, i) => {
    // Slices arranged clockwise starting with Slice 0 centered at 12 o'clock (-PI/2)
    const midAngle = -Math.PI / 2 + (i * slice);
    const startAngle = midAngle - slice / 2;
    const endAngle = midAngle + slice / 2;

    // Draw wedge
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, innerR, startAngle, endAngle);
    ctx.closePath();
    ctx.fillStyle = p.color;
    ctx.fill();

    // Subtle inner depth gradient for 3D wedge feel
    const wedgeGrad = ctx.createRadialGradient(cx, cy, hubR, cx, cy, innerR);
    wedgeGrad.addColorStop(0, 'rgba(255, 255, 255, 0.22)');
    wedgeGrad.addColorStop(0.65, 'rgba(255, 255, 255, 0)');
    wedgeGrad.addColorStop(1, 'rgba(0, 0, 0, 0.22)');
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, innerR, startAngle, endAngle);
    ctx.closePath();
    ctx.fillStyle = wedgeGrad;
    ctx.fill();

    // Spoke divider with metallic chrome highlight
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3.5;
    ctx.stroke();

    // 3. Tactile 3D White Badge Card (Tangential Orientation)
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(midAngle);
    ctx.translate(165, 0);
    ctx.rotate(Math.PI / 2);

    // Determine slice icon & readable label
    let icon = '🎁';
    let mainLabel = p.label;
    let subLabel = '';
    let themeColor = '#0f172a';

    if (p.type === 'cash') {
      if (p.amount >= 300000) {
        icon = '💰';
        mainLabel = '+400K';
        subLabel = 'GRANT';
        themeColor = '#047857'; // emerald
      } else {
        icon = '💎';
        mainLabel = '+250K';
        subLabel = 'BONUS';
        themeColor = '#b45309'; // amber
      }
    } else if (p.type === 'tax') {
      icon = '⚠️';
      mainLabel = '-200K';
      subLabel = 'FINE';
      themeColor = '#be123c'; // rose red
    } else if (p.type === 'island') {
      icon = '🏝️';
      mainLabel = 'ISLAND';
      subLabel = 'JAIL';
      themeColor = '#c2410c'; // orange
    } else if (p.type === 'move') {
      if (p.target === 0) {
        icon = '🚀';
        mainLabel = 'START';
        subLabel = '+300K';
        themeColor = '#0369a1'; // sky blue
      } else {
        icon = '✈️';
        mainLabel = 'TOUR';
        subLabel = 'AIRPORT';
        themeColor = '#6b21a8'; // purple
      }
    }

    // Draw White Tactile Card Plate
    const cw = 112;
    const ch = 64;
    const cr = 14;

    ctx.beginPath();
    if (ctx.roundRect) {
      ctx.roundRect(-cw / 2, -ch / 2, cw, ch, cr);
    } else {
      ctx.rect(-cw / 2, -ch / 2, cw, ch);
    }
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(15, 23, 42, 0.28)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 3;
    ctx.fill();

    // Card border
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.12)';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Top Row: Big Centered Emoji Icon
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = '22px "Segoe UI Emoji", "Apple Color Emoji", sans-serif';
    ctx.fillText(icon, 0, -14);

    // Middle Row: Big Bold Colored Main Amount/Action
    ctx.font = '900 16px Inter, sans-serif';
    ctx.fillStyle = themeColor;
    ctx.fillText(mainLabel, 0, 7);

    // Bottom Row: Subtitle pill/text
    ctx.font = '900 10px Inter, sans-serif';
    ctx.fillStyle = '#64748b';
    ctx.fillText(subLabel, 0, 22);

    ctx.restore();
  });

  // 4. Center Golden Casino Jewel / Hub
  const hubGrad = ctx.createRadialGradient(cx - 8, cy - 8, 4, cx, cy, hubR);
  hubGrad.addColorStop(0, '#fef08a');
  hubGrad.addColorStop(0.4, '#f59e0b');
  hubGrad.addColorStop(0.85, '#d97706');
  hubGrad.addColorStop(1, '#92400e');
  ctx.beginPath();
  ctx.arc(cx, cy, hubR, 0, Math.PI * 2);
  ctx.fillStyle = hubGrad;
  ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
  ctx.shadowBlur = 12;
  ctx.fill();
  ctx.shadowColor = 'transparent';
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 4;
  ctx.stroke();

  // Inner center ruby badge
  ctx.beginPath();
  ctx.arc(cx, cy, hubR - 14, 0, Math.PI * 2);
  ctx.fillStyle = '#b45309';
  ctx.fill();
  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.font = '900 20px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('⭐', cx, cy);
}

export function openChanceWheelModal(isDoubles) {
  if (isLobbyScreenActive()) return;
  gameState.phase = 'MODAL';
  gameState.pendingDoubles = isDoubles;
  if (engineCallbacks.updateUI) engineCallbacks.updateUI();

  // Reset wheel canvas rotation and button
  wheelAngle = 0;
  const canvas = document.getElementById('chance-wheel-canvas');
  if (canvas) {
    canvas.style.transition = 'none';
    canvas.style.transform = 'rotate(0deg)';
  }

  // Ensure result popup is closed
  const resModal = document.getElementById('modal-chance-result');
  if (resModal) {
    resModal.classList.add('hidden');
    resModal.classList.remove('flex');
  }

  drawChanceWheelCanvas();
  const resText = document.getElementById('chance-result-text');
  if (resText) resText.textContent = 'Click Spin to test your luck!';
  const btn = document.getElementById('btn-spin-wheel');
  if (btn) {
    btn.disabled = false;
    btn.innerHTML = `<i class="fa-solid fa-arrows-spin mr-2"></i> SPIN WHEEL`;
  }
  setStatusPill(`🎡 Spin the wheel to test your luck on Chance!`, { isThinking: false, playerIdx: gameState.currentPlayerIdx });

  const m = document.getElementById('modal-chance-wheel');
  m.classList.remove('hidden');
  m.classList.add('flex');
}

export function showChanceAwardPopup(prize, onDone) {
  const m = document.getElementById('modal-chance-result');
  if (!m) {
    if (onDone) onDone();
    return;
  }

  let icon = '🎁';
  let title = prize.label.toUpperCase();
  let actionText = 'Applying rewards to your empire...';
  let tag = 'CHANCE REWARD';
  let tagClass = 'bg-amber-100 text-amber-900 border border-amber-300';
  let iconBg = 'bg-amber-50 text-amber-600';
  let actionClass = 'bg-slate-50 border border-slate-200 text-slate-800';

  if (prize.type === 'cash') {
    icon = prize.amount >= 300000 ? '💰' : '💎';
    title = `+${fmtMoney(prize.amount)} CASH!`;
    actionText = 'Cash deposited directly into your treasury!';
    tag = 'CASH GRANT';
    tagClass = 'bg-emerald-100 text-emerald-900 border border-emerald-300';
    iconBg = 'bg-emerald-50 text-emerald-600';
    actionClass = 'bg-emerald-50 border border-emerald-200 text-emerald-900';
  } else if (prize.type === 'tax') {
    icon = '⚠️';
    title = `TAX AUDIT: -${fmtMoney(prize.amount)}`;
    actionText = 'Fine transferred directly into Festival Pool!';
    tag = 'LUXURY TAX AUDIT';
    tagClass = 'bg-rose-100 text-rose-900 border border-rose-300';
    iconBg = 'bg-rose-50 text-rose-600';
    actionClass = 'bg-rose-50 border border-rose-200 text-rose-900';
  } else if (prize.type === 'island') {
    icon = '🏝️';
    title = 'DETAINED ON ISLAND!';
    actionText = 'Flying to Island! Roll doubles or pay bail to escape.';
    tag = 'DETENTION SURPRISE';
    tagClass = 'bg-orange-100 text-orange-900 border border-orange-300';
    iconBg = 'bg-orange-50 text-orange-600';
    actionClass = 'bg-orange-50 border border-orange-200 text-orange-900';
  } else if (prize.type === 'move') {
    if (prize.target === 0) {
      icon = '🚀';
      title = 'EXPRESS JET TO START!';
      actionText = 'Flying to START to collect +$300,000 salary!';
      tag = 'BOARD WARP';
      tagClass = 'bg-sky-100 text-sky-900 border border-sky-300';
      iconBg = 'bg-sky-50 text-sky-600';
      actionClass = 'bg-sky-50 border border-sky-200 text-sky-900';
    } else {
      icon = '✈️';
      title = 'WORLD TOUR FLIGHT!';
      actionText = 'Flying to Airport for VIP world travel!';
      tag = 'BOARD WARP';
      tagClass = 'bg-purple-100 text-purple-900 border border-purple-300';
      iconBg = 'bg-purple-50 text-purple-600';
      actionClass = 'bg-purple-50 border border-purple-200 text-purple-900';
    }
  }

  const iconEl = document.getElementById('chance-result-icon');
  const titleEl = document.getElementById('chance-result-title');
  const descEl = document.getElementById('chance-result-desc');
  const actionEl = document.getElementById('chance-result-action-text');
  const tagEl = document.getElementById('chance-result-tag');
  const actionContainer = document.getElementById('chance-result-action');
  const timerBar = document.getElementById('chance-result-timer-bar');

  if (iconEl) {
    iconEl.textContent = icon;
    iconEl.className = `w-20 h-20 mx-auto rounded-3xl flex items-center justify-center text-4xl shadow-md border-2 border-slate-100 ${iconBg}`;
  }
  if (titleEl) titleEl.textContent = title;
  if (descEl) descEl.textContent = prize.desc;
  if (actionEl) actionEl.textContent = actionText;
  if (tagEl) {
    tagEl.textContent = tag;
    tagEl.className = `inline-block text-xs font-black uppercase px-3.5 py-1 rounded-full ${tagClass}`;
  }
  if (actionContainer) {
    actionContainer.className = `py-2.5 px-3.5 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 ${actionClass}`;
  }

  if (timerBar) {
    timerBar.style.transition = 'none';
    timerBar.style.width = '100%';
    void timerBar.offsetWidth;
    timerBar.style.transition = 'width 2000ms linear';
    timerBar.style.width = '0%';
  }

  m.classList.remove('hidden');
  m.classList.add('flex');

  // Exactly 2000ms (2 seconds)
  setTimeout(() => {
    m.classList.add('hidden');
    m.classList.remove('flex');
    if (onDone) onDone();
  }, 2000);
}

export function spinChanceWheel() {
  const btn = document.getElementById('btn-spin-wheel');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i> SPINNING...`;
  }

  const prizeIdx = Math.floor(Math.random() * CHANCE_WHEEL_PRIZES.length);
  const prize = CHANCE_WHEEL_PRIZES[prizeIdx];

  // N slices. Slice 0 is centered at 12 o'clock.
  // Slice i is at (i * 60) degrees clockwise from 12 o'clock.
  // To bring slice i to 12 o'clock under the needle, target rotation mod 360 is:
  const N = CHANCE_WHEEL_PRIZES.length;
  const sliceDeg = 360 / N;
  const targetOffset = (360 - (prizeIdx * sliceDeg)) % 360;

  // Add 5-6 full spins
  const fullSpins = 5 + Math.floor(Math.random() * 2);
  const currentMod = wheelAngle % 360;
  let forwardDelta = targetOffset - currentMod;
  if (forwardDelta <= 0) forwardDelta += 360;
  wheelAngle += (fullSpins * 360) + forwardDelta;

  const canvas = document.getElementById('chance-wheel-canvas');
  if (canvas) {
    canvas.style.transition = 'transform 2600ms cubic-bezier(0.12, 0.9, 0.25, 1)';
    canvas.style.transform = `rotate(${wheelAngle}deg)`;
  }

  // Ticking sound simulation as wheel spins and decelerates
  const totalSpinMs = 2600;
  let tickInterval = 60;
  const startSpinTime = Date.now();
  function scheduleNextTick() {
    const elapsed = Date.now() - startSpinTime;
    if (elapsed >= totalSpinMs - 120) return;
    playSFX('wheelTick', 0.7);
    const progress = elapsed / totalSpinMs;
    tickInterval = 55 + Math.pow(progress, 2.5) * 320;
    setTimeout(scheduleNextTick, tickInterval);
  }
  scheduleNextTick();

  setTimeout(async () => {
    if (isLobbyScreenActive()) return;
    playSFX('win');

    // 1. Immediately highlight the result in the box below the wheel
    const resultText = document.getElementById('chance-result-text');
    if (resultText) {
      resultText.innerHTML = `<strong>${prize.label}</strong>: ${prize.desc}`;
    }

    // 2. Wait 0.85s so user can clearly see the wheel resting right on the prize
    await new Promise(r => setTimeout(r, 850));
    if (isLobbyScreenActive()) return;

    // 3. Close the wheel modal
    document.getElementById('modal-chance-wheel').classList.add('hidden');
    document.getElementById('modal-chance-wheel').classList.remove('flex');

    // 4. Show the dedicated, 100% solid, crystal-clear 2-second award popup
    showChanceAwardPopup(prize, async () => {
      // 5. Run the in-game 3D flight/tax/cash animation!
      const activePIdx = (gameState.currentPlayerIdx !== undefined && gameState.currentPlayerIdx !== null)
        ? gameState.currentPlayerIdx
        : 0;
      if (engineCallbacks.applyChancePrize) {
        await engineCallbacks.applyChancePrize(activePIdx, prize, gameState.pendingDoubles);
      }
    });
  }, 2650);
}

/* ─────────────────────────────────────────────────────────────────────────────
   D. TILE INSPECTOR MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openInspectorModal(tileId) {
  if (isLobbyScreenActive()) return;
  const tile = BOARD_TILES[tileId];
  if (!tile) return;
  gameState.activeInspectorTile = tileId;

  setTileHighlightRing(tile.id, true);

  const st = gameState.properties[tileId];
  const header = document.getElementById('insp-header');
  header.style.background = tile.group ? GROUP_META[tile.group].hex : '#475569';

  document.getElementById('insp-group').textContent = tile.group ? GROUP_META[tile.group].name : tile.type.toUpperCase();
  document.getElementById('insp-title').textContent = tile.name;

  const myIdx = (typeof localPlayerIdx === 'number' ? localPlayerIdx : 0);
  const myPlayer = gameState.players[myIdx] || gameState.players[0];
  const isOwnedByLocalPlayer = (st && st.owner === myIdx);
  const isStandingOnTile = (myPlayer && myPlayer.position === tileId);

  const ownerPill = document.getElementById('insp-owner-pill');
  if (st && st.owner !== null) {
    if (isOwnedByLocalPlayer) {
      const levelDesc = st.mortgaged ? 'MORTGAGED' : (st.level === 4 ? 'Skyscraper (MAX)' : (st.level > 0 ? `${st.level} House${st.level > 1 ? 's' : ''}` : 'Base Land'));
      ownerPill.className = `text-xs sm:text-sm font-display font-black text-center py-2 px-3 rounded-2xl ${st.mortgaged ? 'bg-rose-50 text-rose-800 border-2 border-rose-300' : 'bg-emerald-50 text-emerald-900 border-2 border-emerald-300'} shadow-2xs`;
      ownerPill.innerHTML = `<i class="fa-solid fa-crown ${st.mortgaged ? 'text-rose-600' : 'text-amber-500'} mr-1"></i> Your Estate • ${levelDesc}`;
    } else {
      const ownerName = gameState.players[st.owner]?.name || 'Opponent';
      ownerPill.className = 'text-xs sm:text-sm font-display font-black text-center py-2 px-3 rounded-2xl bg-slate-100 text-slate-800 border-2 border-slate-200/80 shadow-2xs';
      ownerPill.innerHTML = `Owned by <strong>${ownerName}</strong> ${st.mortgaged ? '<span class="text-rose-600 font-black">(MORTGAGED)</span>' : ''}`;
    }
  } else if (tile.price) {
    ownerPill.className = 'text-xs sm:text-sm font-display font-black text-center py-2 px-3 rounded-2xl bg-amber-50 text-amber-950 border-2 border-amber-300/80 shadow-2xs';
    ownerPill.innerHTML = `Unowned • Price: <strong class="text-emerald-700">${fmtMoney(tile.price)}</strong>`;
  } else {
    ownerPill.className = 'text-xs sm:text-sm font-display font-black text-center py-2 px-3 rounded-2xl bg-slate-100 text-slate-800 border-2 border-slate-200/80 shadow-2xs';
    ownerPill.textContent = tile.subtitle || 'Special Landmark';
  }

  const rentList = document.getElementById('insp-rent-list');
  if (tile.type === 'city') {
    const curLevel = (st && !st.mortgaged) ? (st.level || 0) : -1;
    const tierLabels = ['Base Land', '1 House', '2 Houses', '3 Houses', 'Skyscraper'];
    rentList.innerHTML = [0, 1, 2, 3, 4].map(idx => {
      const isCurrent = (curLevel === idx);
      const isSky = (idx === 4);
      const cardClass = isCurrent
        ? 'game-tier-card tier-card-current'
        : (isSky ? 'game-tier-card tier-card-skyscraper' : 'game-tier-card');
      const valPillClass = isCurrent
        ? 'tier-val-pill bg-emerald-600 text-white border-emerald-500 shadow-xs'
        : (isSky ? 'tier-val-pill tier-val-skyscraper' : 'tier-val-pill');
      const activeTag = isCurrent
        ? '<span class="text-[9px] uppercase px-1.5 py-0.5 rounded-full bg-emerald-600 text-white font-black ml-1.5 shadow-2xs">ACTIVE</span>'
        : '';
      return `
        <div class="${cardClass} py-1.5 px-2.5">
          <div class="flex items-center gap-2">
            ${getTierBadgeHTML(idx)}
            <div class="flex items-center">
              <span class="font-display font-bold text-xs text-slate-800">${tierLabels[idx]}</span>
              ${activeTag}
            </div>
          </div>
          <div class="${valPillClass} text-xs py-1 px-2.5 font-black">${fmtMoney(tile.rent[idx])}</div>
        </div>
      `;
    }).join('');
  } else if (tile.type === 'resort') {
    rentList.innerHTML = `
      <div class="game-tier-card py-2 px-3">
        <div class="flex items-center gap-2">
          <div class="tier-level-badge tier-house">🌴</div>
          <span class="font-display font-bold text-xs text-slate-800">1 Resort Owned</span>
        </div>
        <div class="tier-val-pill text-xs py-1 px-2.5 font-black">${fmtMoney(tile.rent[0])}</div>
      </div>
      <div class="game-tier-card tier-card-skyscraper py-2 px-3">
        <div class="flex items-center gap-2">
          <div class="tier-level-badge tier-skyscraper-badge">🏖️</div>
          <span class="font-display font-bold text-xs text-amber-950">2 Resorts Owned (2×)</span>
        </div>
        <div class="tier-val-pill tier-val-skyscraper text-xs py-1 px-2.5 font-black">${fmtMoney(tile.rent[1])}</div>
      </div>
    `;
  } else {
    rentList.innerHTML = `<div class="p-3 bg-white rounded-2xl border border-slate-200 text-center font-bold text-xs text-slate-700">${tile.subtitle || 'Land here to trigger special board rules.'}</div>`;
  }

  const actionsEl = document.getElementById('insp-actions');
  actionsEl.innerHTML = '';

  if (!isOwnedByLocalPlayer) {
    // Tile is unowned or owned by someone else -> strictly do NOT show upgrade or mortgage buttons
    actionsEl.innerHTML = '';
  } else {
    // Tile is owned by local player
    if (!isStandingOnTile) {
      // Player is NOT at this city -> do NOT show upgrade or mortgage buttons
      actionsEl.innerHTML = `
        <div class="py-2.5 px-3 rounded-2xl bg-slate-100 border border-slate-200 text-slate-500 font-bold text-xs text-center flex items-center justify-center gap-1.5 shadow-2xs">
          <i class="fa-solid fa-location-dot text-slate-400"></i>
          <span>Land here to build upgrades or mortgage</span>
        </div>
      `;
    } else if (!isHumanTurnActionable()) {
      // Player is at this city, but it's not their turn
      actionsEl.innerHTML = `
        <div class="w-full py-2.5 px-3 rounded-xl bg-amber-50 border-2 border-amber-300 text-amber-950 font-black text-xs text-center flex items-center justify-center gap-1.5 shadow-xs">
          <i class="fa-solid fa-lock text-amber-600"></i>
          <span>Wait for your turn to build or mortgage</span>
        </div>
      `;
    } else {
      // Player owns city, is standing on it, and it's their actionable turn!
      let html = '';
      if (tile.type === 'city' && !st.mortgaged) {
        const canUp = st.level < 4 && myPlayer.cash >= tile.houseCost;
        const canDown = st.level > 0;
        html += `
          <div class="grid grid-cols-2 gap-2">
            <button onclick="window.upgradeCityLevel(${tileId})" ${!canUp ? 'disabled' : ''} class="game-btn ${canUp ? 'game-btn-green' : 'game-btn-slate opacity-50 cursor-not-allowed'} py-2.5 text-xs font-black">
              +Upgrade (${fmtMoney(tile.houseCost)})
            </button>
            <button onclick="window.downgradeCityLevel(${tileId})" ${!canDown ? 'disabled' : ''} class="game-btn ${canDown ? 'game-btn-orange' : 'game-btn-slate opacity-50 cursor-not-allowed'} py-2.5 text-xs font-black">
              -Sell (+${fmtMoney(tile.houseCost / 2)})
            </button>
          </div>
        `;
      }

      const unmortCost = Math.round(tile.price * 0.55);
      if (!st.mortgaged && (st.level || 0) === 0) {
        html += `
          <button onclick="window.toggleCityMortgage(${tileId})" class="game-btn game-btn-red w-full py-2.5 text-xs font-black">
            Mortgage City (+${fmtMoney(tile.price / 2)})
          </button>
        `;
      } else if (st.mortgaged) {
        const canAffordUnmort = myPlayer.cash >= unmortCost;
        html += `
          <button onclick="window.toggleCityMortgage(${tileId})" ${!canAffordUnmort ? 'disabled' : ''} class="game-btn ${canAffordUnmort ? 'game-btn-blue' : 'game-btn-slate opacity-50 cursor-not-allowed'} w-full py-2.5 text-xs font-black">
            Unmortgage City (-${fmtMoney(unmortCost)})
          </button>
        `;
      }
      actionsEl.innerHTML = html;
    }
  }

  populateCityPreview3DScene(tile, 'insp-city-3d-canvas');

  const m = document.getElementById('modal-tile-inspector');
  const card = document.getElementById('modal-tile-inspector-card');
  m.classList.remove('hidden');
  m.classList.add('flex');

  if (card) {
    const isPlayerOnTile = (myPlayer?.position === tileId);
    const canBeUpgraded = (tile.type === 'city' && st && isOwnedByLocalPlayer && !st.mortgaged && st.level < 4);
    if (isPlayerOnTile && canBeUpgraded) {
      const color = tile.group ? GROUP_META[tile.group].hex : '#0284c7';
      card.style.borderColor = color;
      card.style.boxShadow = `0 14px 35px -6px ${color}50, 0 0 20px 2px ${color}35`;
    } else {
      card.style.borderColor = '';
      card.style.boxShadow = '';
    }
    card.classList.remove('tile-inspector-exit', 'tile-inspector-pulse', 'tile-inspector-enter');
    void card.offsetWidth;
    card.classList.add('tile-inspector-enter');
    playSFX('hop');
  }
}

export function closeInspectorModal() {
  const m = document.getElementById('modal-tile-inspector');
  const card = document.getElementById('modal-tile-inspector-card');
  setTileHighlightRing(0, false);

  if (card && !m.classList.contains('hidden')) {
    card.style.borderColor = '';
    card.style.boxShadow = '';
    card.classList.remove('tile-inspector-enter', 'tile-inspector-pulse');
    card.classList.add('tile-inspector-exit');
    setTimeout(() => {
      m.classList.add('hidden');
      m.classList.remove('flex');
      card.classList.remove('tile-inspector-exit');
      clearCityPreview();
    }, 220);
  } else {
    m.classList.add('hidden');
    m.classList.remove('flex');
    clearCityPreview();
  }
  gameState.activeInspectorTile = null;
}

// Light dismiss: clicking anywhere outside the inspector card closes it
if (typeof window !== 'undefined') {
  window.addEventListener('pointerdown', (e) => {
    const m = document.getElementById('modal-tile-inspector');
    const card = document.getElementById('modal-tile-inspector-card');
    if (!m || m.classList.contains('hidden')) return;

    // Keep open if clicked inside the inspector card
    if (card && card.contains(e.target)) return;

    // If clicking on 3D canvas, handleCanvasClick handles tile selection vs empty board click
    const canvasContainer = document.getElementById('three-canvas-container');
    if (canvasContainer && (e.target === canvasContainer || canvasContainer.contains(e.target))) {
      return;
    }

    // Clicked anywhere else in the document
    closeInspectorModal();
  });
}

export function upgradeCityLevel(tileId, isForcedAI = false) {
  const st = gameState.properties[tileId];
  const tile = BOARD_TILES[tileId];
  if (!st || st.owner === null || st.mortgaged || st.level >= 4) return;
  const p = gameState.players[st.owner];
  if (!isForcedAI && p.position !== tileId) {
    showTurnLockToast("You can only upgrade the property you are standing on!");
    return;
  }
  if (st.owner === localPlayerIdx && !isForcedAI && !isHumanTurnActionable()) {
    showTurnLockToast("Wait for your turn to upgrade cities!");
    return;
  }
  if (!isForcedAI && (gameState.upgradesThisVisit || 0) >= 2) {
    showTurnLockToast("You can only upgrade at most 2 levels at one time!");
    return;
  }
  if (p.cash < tile.houseCost) return;

  p.cash -= tile.houseCost;
  st.level++;
  if (!isForcedAI) {
    gameState.upgradesThisVisit = (gameState.upgradesThisVisit || 0) + 1;
  }
  playSFX('build');
  if (engineCallbacks.spawnFloatingCash) engineCallbacks.spawnFloatingCash(st.owner, `-${fmtMoney(tile.houseCost)}`, false);
  logEvent(`🏗️ <strong>${p.name}</strong> upgraded <strong>${tile.name}</strong> to Level ${st.level}!`);

  if (networkState.isMultiplayer && !isForcedAI) {
    broadcastAction('ACTION_UPGRADE_CITY', { playerIdx: st.owner, tileId });
  }

  refreshTileTextureAndBuildings(tileId);
  renderCornerHUDs();
  saveCurrentMatchToStorage();
  if (gameState.activeInspectorTile === tileId) openInspectorModal(tileId);
  if (!document.getElementById('modal-portfolio').classList.contains('hidden')) renderPortfolioGrid();
}

export function downgradeCityLevel(tileId, isAutoLiquidation = false) {
  const st = gameState.properties[tileId];
  const tile = BOARD_TILES[tileId];
  if (!st || st.owner === null || st.level <= 0) return;
  if (st.owner === localPlayerIdx && !isAutoLiquidation && !isHumanTurnActionable()) {
    showTurnLockToast("Wait for your turn to sell buildings!");
    return;
  }
  const p = gameState.players[st.owner];
  const refund = tile.houseCost / 2;

  p.cash += refund;
  st.level--;
  playSFX('cash');
  if (engineCallbacks.spawnFloatingCash) engineCallbacks.spawnFloatingCash(st.owner, `+${fmtMoney(refund)}`, true);

  refreshTileTextureAndBuildings(tileId);
  renderCornerHUDs();
  saveCurrentMatchToStorage();
  if (gameState.activeInspectorTile === tileId) openInspectorModal(tileId);
  if (!document.getElementById('modal-portfolio').classList.contains('hidden')) renderPortfolioGrid();
}

export function toggleCityMortgage(tileId, isAutoLiquidation = false) {
  const st = gameState.properties[tileId];
  const tile = BOARD_TILES[tileId];
  if (!st || st.owner === null) return;
  if (st.owner === localPlayerIdx && !isAutoLiquidation && !isHumanTurnActionable()) {
    showTurnLockToast("Wait for your turn to mortgage cities!");
    return;
  }
  const p = gameState.players[st.owner];

  if (!st.mortgaged) {
    const gain = tile.price / 2;
    st.mortgaged = true;
    p.cash += gain;
    playSFX('cash');
    if (engineCallbacks.spawnFloatingCash) engineCallbacks.spawnFloatingCash(st.owner, `+${fmtMoney(gain)}`, true);
    logEvent(`🏦 <strong>${p.name}</strong> mortgaged <strong>${tile.name}</strong> (+${fmtMoney(gain)}).`);
  } else {
    const cost = Math.round(tile.price * 0.55);
    if (p.cash < cost) return;
    p.cash -= cost;
    st.mortgaged = false;
    playSFX('cash');
    if (engineCallbacks.spawnFloatingCash) engineCallbacks.spawnFloatingCash(st.owner, `-${fmtMoney(cost)}`, false);
    logEvent(`🏦 <strong>${p.name}</strong> unmortgaged <strong>${tile.name}</strong> (-${fmtMoney(cost)}).`);
  }

  if (networkState.isMultiplayer && !isAutoLiquidation) {
    broadcastAction('ACTION_MORTGAGE_CITY', { playerIdx: st.owner, tileId, mortgaged: st.mortgaged });
  }

  refreshTileTextureAndBuildings(tileId);
  renderCornerHUDs();
  saveCurrentMatchToStorage();
  if (gameState.activeInspectorTile === tileId) openInspectorModal(tileId);
  if (!document.getElementById('modal-portfolio').classList.contains('hidden')) renderPortfolioGrid();
}

/* ─────────────────────────────────────────────────────────────────────────────
   E. MANAGE CITIES PORTFOLIO MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openPortfolioModal() {
  if (isLobbyScreenActive()) return;
  if (!isHumanTurnActionable()) {
    showTurnLockToast("Wait for your turn to manage cities!");
    return;
  }
  renderPortfolioGrid();
  const m = document.getElementById('modal-portfolio');
  m.classList.remove('hidden');
  m.classList.add('flex');
}

export function closePortfolioModal() {
  document.getElementById('modal-portfolio').classList.add('hidden');
  document.getElementById('modal-portfolio').classList.remove('flex');
}

export function renderPortfolioGrid() {
  const grid = document.getElementById('portfolio-grid');
  const owned = BOARD_TILES.filter(t => gameState.properties[t.id] && gameState.properties[t.id].owner === 0);

  if (owned.length === 0) {
    grid.innerHTML = `<div class="col-span-2 text-center py-8 text-slate-700 text-sm font-black">You haven't bought any cities yet! Roll the dice to start your empire.</div>`;
    return;
  }

  grid.innerHTML = owned.map(t => {
    const st = gameState.properties[t.id];
    const color = t.group ? GROUP_META[t.group].hex : '#0284c7';
    const isPlayerOnTile = (gameState.players[0].position === t.id);
    const upgradesLeft = Math.max(0, 2 - (gameState.upgradesThisVisit || 0));
    const canBeUpgraded = (t.type === 'city' && !st.mortgaged && st.level < 4 && upgradesLeft > 0);
    const isIlluminated = isPlayerOnTile && canBeUpgraded;

    const cardClass = isIlluminated
      ? 'rounded-2xl p-3.5 flex flex-col justify-between gap-3 shadow-md transition-[transform,box-shadow,border-color,background-color] duration-300 transform scale-[1.01]'
      : 'bg-slate-50 border-2 border-slate-200 rounded-2xl p-3.5 flex flex-col justify-between gap-3 shadow-xs';

    const cardStyle = isIlluminated
      ? `background: linear-gradient(145deg, ${color}26, ${color}0f); border: 2.5px solid ${color}; box-shadow: 0 10px 24px -4px ${color}45, 0 0 16px 2px ${color}30, inset 0 1px 2px 0 rgba(255,255,255,0.95);`
      : '';

    return `
      <div class="${cardClass}" style="${cardStyle}">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="w-4 h-4 rounded-full border border-black/20" style="background:${color}; ${isIlluminated ? `box-shadow: 0 0 8px ${color};` : ''}"></span>
            <span class="font-black text-sm text-slate-900">${t.name}</span>
            ${isIlluminated ? `
              <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase text-white shadow-2xs flex items-center gap-1" style="background:${color}">
                <i class="fa-solid fa-location-dot"></i> ACTIVE (${2 - upgradesLeft}/2)
              </span>
            ` : ''}
          </div>
          <span class="text-xs sm:text-sm font-black ${st.mortgaged ? 'text-rose-700' : 'text-emerald-700'}">
            ${st.mortgaged ? 'MORTGAGED' : `Rent: ${fmtMoney(calculateTileRent(t.id))}`}
          </span>
        </div>
        <div class="flex gap-2">
          ${t.type === 'city' && !st.mortgaged ? `
            ${isPlayerOnTile ? `
              ${canBeUpgraded ? `
                <button onclick="window.upgradeCityLevel(${t.id})" class="game-btn game-btn-green flex-1 py-2 text-xs sm:text-sm font-black shadow-md">
                  <i class="fa-solid fa-arrow-up-right-dots mr-1"></i> +Upgrade (${fmtMoney(t.houseCost)}) <span class="text-xs opacity-90 font-bold ml-1">(${2 - upgradesLeft}/2)</span>
                </button>
              ` : `
                <div class="flex-1 py-2 text-xs font-extrabold text-slate-600 bg-slate-100 rounded-xl text-center flex items-center justify-center gap-1 border border-slate-200">
                  <i class="fa-solid fa-ban text-amber-500"></i> ${st.level >= 4 ? 'Max Level' : 'Max 2/visit reached'}
                </div>
              `}
            ` : `
              <div class="flex-1 py-2 text-xs font-extrabold text-slate-600 bg-slate-100 rounded-xl text-center flex items-center justify-center gap-1 border border-slate-200" title="You can only upgrade when your avatar is standing on this tile">
                <i class="fa-solid fa-location-dot text-amber-500"></i> Land here to upgrade
              </div>
            `}
          ` : ''}
          <button onclick="window.toggleCityMortgage(${t.id})" class="game-btn ${st.mortgaged ? 'game-btn-blue' : 'game-btn-slate'} flex-1 py-2 text-xs sm:text-sm font-black">
            ${st.mortgaged ? 'Unmortgage' : `Mortgage (+${fmtMoney(t.price/2)})`}
          </button>
        </div>
      </div>
    `;
  }).join('');
}

/* ─────────────────────────────────────────────────────────────────────────────
   F. DIPLOMATIC TRADE MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openTradeModal() {
  if (isLobbyScreenActive()) return;
  if (!isHumanTurnActionable()) {
    showTurnLockToast("Wait for your turn to propose a trade!");
    return;
  }
  const myIdx = localPlayerIdx || 0;
  const sel = document.getElementById('trade-partner-select');
  sel.innerHTML = '';
  gameState.players.forEach((p, idx) => {
    if (idx !== myIdx && !p.bankrupt) {
      const o = document.createElement('option');
      o.value = idx;
      o.textContent = p.name;
      sel.appendChild(o);
    }
  });

  const myProps = BOARD_TILES.filter(t => gameState.properties[t.id] && gameState.properties[t.id].owner === myIdx);
  document.getElementById('trade-offer-props').innerHTML = myProps.map(t => `
    <label class="flex items-center justify-between text-xs font-black bg-white px-3 py-2 rounded-xl border-2 border-slate-200 text-slate-800 cursor-pointer hover:border-slate-300">
      <span class="flex items-center gap-1.5"><input type="checkbox" value="${t.id}" class="trade-my-prop mr-1 w-3.5 h-3.5">${t.name}</span>
      <span class="font-black text-emerald-700">${fmtMoney(t.price)}</span>
    </label>
  `).join('') || '<div class="text-xs font-bold text-slate-500 py-2 text-center">No cities owned</div>';

  populateTradePartnerProps();
  document.getElementById('trade-status-msg').classList.add('hidden');
  const m = document.getElementById('modal-trade');
  m.classList.remove('hidden');
  m.classList.add('flex');
}

export function populateTradePartnerProps() {
  const pIdx = parseInt(document.getElementById('trade-partner-select').value, 10);
  if (isNaN(pIdx)) return;
  const props = BOARD_TILES.filter(t => gameState.properties[t.id] && gameState.properties[t.id].owner === pIdx);
  document.getElementById('trade-req-props').innerHTML = props.map(t => `
    <label class="flex items-center justify-between text-xs font-black bg-white px-3 py-2 rounded-xl border-2 border-slate-200 text-slate-800 cursor-pointer hover:border-slate-300">
      <span class="flex items-center gap-1.5"><input type="checkbox" value="${t.id}" class="trade-their-prop mr-1 w-3.5 h-3.5">${t.name}</span>
      <span class="font-black text-emerald-700">${fmtMoney(t.price)}</span>
    </label>
  `).join('') || '<div class="text-xs font-bold text-slate-500 py-2 text-center">No cities owned</div>';
}

let pendingTradeCounter = null;
let activeIncomingTradeProposal = null;

export function completeTradeTransfer(giverIdx, receiverIdx, offerCash, reqCash, offerTileIds, reqTileIds) {
  const giver = gameState.players[giverIdx];
  const receiver = gameState.players[receiverIdx];
  if (!giver || !receiver) return;

  giver.cash = giver.cash - offerCash + reqCash;
  receiver.cash = receiver.cash - reqCash + offerCash;

  offerTileIds.forEach(id => {
    if (gameState.properties[id]) {
      gameState.properties[id].owner = receiverIdx;
      refreshTileTextureAndBuildings(id);
    }
  });

  reqTileIds.forEach(id => {
    if (gameState.properties[id]) {
      gameState.properties[id].owner = giverIdx;
      refreshTileTextureAndBuildings(id);
    }
  });

  const affectedGroups = new Set();
  [...offerTileIds, ...reqTileIds].forEach(id => {
    if (BOARD_TILES[id]?.group) affectedGroups.add(BOARD_TILES[id].group);
  });
  affectedGroups.forEach(grp => {
    checkAndTriggerMonopoly(giverIdx, grp);
    checkAndTriggerMonopoly(receiverIdx, grp);
  });

  playSFX('cash');
  renderCornerHUDs();
  saveCurrentMatchToStorage();

  const vic = checkVictoryConditions();
  if (vic) {
    clearSavedMatch();
    showVictoryModal(vic.winner, vic);
  }
}

export function executeTradeOffer() {
  const partnerIdx = parseInt(document.getElementById('trade-partner-select').value, 10);
  if (isNaN(partnerIdx)) return;
  const myIdx = localPlayerIdx || 0;
  const me = gameState.players[myIdx];
  const partner = gameState.players[partnerIdx];

  const offerCash = (parseInt(document.getElementById('trade-offer-cash').value || '0', 10)) * 1000;
  const reqCash = (parseInt(document.getElementById('trade-req-cash').value || '0', 10)) * 1000;
  const myIds = Array.from(document.querySelectorAll('.trade-my-prop:checked')).map(e => parseInt(e.value, 10));
  const theirIds = Array.from(document.querySelectorAll('.trade-their-prop:checked')).map(e => parseInt(e.value, 10));

  const msg = document.getElementById('trade-status-msg');
  const banner = document.getElementById('trade-counter-banner');
  if (banner) banner.classList.add('hidden');
  msg.classList.remove('hidden');

  if (offerCash > me.cash || reqCash > partner.cash) {
    msg.className = 'text-center text-xs font-extrabold py-1 text-rose-600';
    msg.textContent = 'Not enough cash for this trade!';
    return;
  }

  // Evaluate through objective trading engine
  const evalResult = evaluateTradeDeal(partnerIdx, myIdx, offerCash, reqCash, myIds, theirIds);

  if (evalResult.status === 'accept') {
    completeTradeTransfer(myIdx, partnerIdx, offerCash, reqCash, myIds, theirIds);
    logEvent(`🤝 <strong>Trade Completed!</strong> ${me.name} and ${partner.name} concluded their deal.`);
    closeTradeModal();
  } else if (evalResult.status === 'counter' && evalResult.counterOffer) {
    pendingTradeCounter = evalResult.counterOffer;
    const title = document.getElementById('counter-offer-title');
    const desc = document.getElementById('counter-offer-desc');
    if (banner && title && desc) {
      title.textContent = `Counter-Offer from ${partner.name}`;
      desc.innerHTML = `<strong>${partner.name}</strong> is willing to deal if you raise cash offer to <strong>${fmtMoney(evalResult.counterOffer.offerCash)}</strong> (+${fmtMoney(evalResult.counterOffer.deficit)}).`;
      banner.classList.remove('hidden');
    }
    msg.className = 'text-center text-xs font-bold py-1 text-amber-700';
    msg.textContent = evalResult.reason;
  } else {
    msg.className = 'text-center text-xs font-extrabold py-1 text-rose-600';
    msg.textContent = evalResult.reason || `${partner.name} declined the trade.`;
  }
}

export function acceptTradeCounterOffer() {
  if (!pendingTradeCounter) return;
  const { giverIdx, receiverIdx, offerCash, reqCash, offerTileIds, reqTileIds } = pendingTradeCounter;
  const giver = gameState.players[giverIdx];
  const receiver = gameState.players[receiverIdx];
  if (giver.cash < offerCash) {
    const msg = document.getElementById('trade-status-msg');
    if (msg) {
      msg.className = 'text-center text-xs font-extrabold py-1 text-rose-600';
      msg.textContent = `Insufficient cash! You need ${fmtMoney(offerCash)}.`;
      msg.classList.remove('hidden');
    }
    return;
  }
  completeTradeTransfer(giverIdx, receiverIdx, offerCash, reqCash, offerTileIds, reqTileIds);
  logEvent(`🤝 <strong>Counter-Offer Accepted!</strong> ${giver.name} agreed to ${receiver.name}'s terms.`);
  pendingTradeCounter = null;
  const banner = document.getElementById('trade-counter-banner');
  if (banner) banner.classList.add('hidden');
  closeTradeModal();
}

export function rejectTradeCounterOffer() {
  pendingTradeCounter = null;
  const banner = document.getElementById('trade-counter-banner');
  if (banner) banner.classList.add('hidden');
  const msg = document.getElementById('trade-status-msg');
  if (msg) {
    msg.className = 'text-center text-xs font-bold py-1 text-slate-600';
    msg.textContent = 'Counter-offer declined.';
    msg.classList.remove('hidden');
  }
}

export function closeTradeModal() {
  const m = document.getElementById('modal-trade');
  if (m) {
    m.classList.add('hidden');
    m.classList.remove('flex');
  }
  const banner = document.getElementById('trade-counter-banner');
  if (banner) banner.classList.add('hidden');
  pendingTradeCounter = null;
}

export function showIncomingTradeOfferModal(proposal) {
  if (isLobbyScreenActive()) return;
  activeIncomingTradeProposal = proposal;
  const bot = gameState.players[proposal.proposerIdx];
  const target = gameState.players[proposal.targetIdx];
  if (!bot || !target) return;

  const botNameEl = document.getElementById('incoming-trade-bot-name');
  if (botNameEl) botNameEl.textContent = bot.name;

  const offerCashEl = document.getElementById('incoming-they-offer-cash');
  if (offerCashEl) {
    offerCashEl.textContent = proposal.offerCash > 0 ? `+${fmtMoney(proposal.offerCash)} Cash` : 'No cash offered';
  }

  const offerPropsEl = document.getElementById('incoming-they-offer-props');
  if (offerPropsEl) {
    if (proposal.offerTileIds?.length > 0) {
      offerPropsEl.innerHTML = proposal.offerTileIds.map(id => {
        const t = BOARD_TILES[id];
        return `<div class="flex items-center justify-between text-xs py-1 border-b border-slate-100">
          <span>🏙️ ${t.name}</span>
          <span class="text-emerald-700 font-extrabold">${fmtMoney(t.price)}</span>
        </div>`;
      }).join('');
    } else {
      offerPropsEl.innerHTML = '<span class="text-xs text-slate-400 italic">No properties</span>';
    }
  }

  const reqCashEl = document.getElementById('incoming-they-req-cash');
  if (reqCashEl) {
    reqCashEl.textContent = proposal.reqCash > 0 ? `${fmtMoney(proposal.reqCash)} Cash` : 'No cash';
  }

  const reqPropsEl = document.getElementById('incoming-they-req-props');
  if (reqPropsEl) {
    if (proposal.reqTileIds?.length > 0) {
      reqPropsEl.innerHTML = proposal.reqTileIds.map(id => {
        const t = BOARD_TILES[id];
        return `<div class="flex items-center justify-between text-xs py-1 border-b border-slate-100">
          <span>🏙️ ${t.name}</span>
          <span class="text-amber-700 font-extrabold">${fmtMoney(t.price)}</span>
        </div>`;
      }).join('');
    } else {
      reqPropsEl.innerHTML = '<span class="text-xs text-slate-400 italic">No properties</span>';
    }
  }

  const rationaleEl = document.getElementById('incoming-trade-rationale');
  if (rationaleEl) {
    const reqNames = (proposal.reqTileIds || []).map(id => BOARD_TILES[id].name).join(', ');
    rationaleEl.innerHTML = `<strong>${bot.name}</strong> is looking to acquire <strong>${reqNames}</strong> and offers an equitable compensation package.`;
  }

  const modal = document.getElementById('modal-incoming-trade');
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    playSFX('hop');
  }
}

export function closeIncomingTradeModal() {
  const modal = document.getElementById('modal-incoming-trade');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
  activeIncomingTradeProposal = null;
}

export function acceptIncomingTrade() {
  if (!activeIncomingTradeProposal) return;
  const p = activeIncomingTradeProposal;
  completeTradeTransfer(p.proposerIdx, p.targetIdx, p.offerCash, p.reqCash, p.offerTileIds, p.reqTileIds);
  const bot = gameState.players[p.proposerIdx];
  const target = gameState.players[p.targetIdx];
  logEvent(`🤝 <strong>Trade Deal Struck!</strong> ${target.name} accepted ${bot.name}'s proposal.`);
  closeIncomingTradeModal();
}

export function counterIncomingTrade() {
  if (!activeIncomingTradeProposal) return;
  const p = activeIncomingTradeProposal;
  closeIncomingTradeModal();
  openTradeModal();
  const sel = document.getElementById('trade-partner-select');
  if (sel) {
    sel.value = p.proposerIdx;
    populateTradePartnerProps();
  }
}

export function declineIncomingTrade() {
  if (!activeIncomingTradeProposal) return;
  const bot = gameState.players[activeIncomingTradeProposal.proposerIdx];
  logEvent(`❌ Proactive trade offer from <strong>${bot?.name || 'Bot'}</strong> declined.`);
  closeIncomingTradeModal();
}

/* ─────────────────────────────────────────────────────────────────────────────
   G. VICTORY CELEBRATION MODAL
───────────────────────────────────────────────────────────────────────────── */
export function showVictoryModal(winner, victoryDetails = null) {
  if (isLobbyScreenActive()) return;
  const winnerObj = winner || gameState.players.find(p => !p.bankrupt) || gameState.players[0];
  const isLocalHuman = winnerObj && (winnerObj.id === localPlayerIdx || (!winnerObj.isAI && (localPlayerIdx === undefined || localPlayerIdx === 0)));

  const titleEl = document.getElementById('victory-title');
  if (titleEl) {
    if (victoryDetails?.type === 'triple_monopoly') {
      titleEl.textContent = isLocalHuman ? 'TRIPLE MONOPOLY!' : `${winnerObj?.name || 'Player'} TRIPLE WIN!`;
    } else if (victoryDetails?.type === 'line_monopoly') {
      titleEl.textContent = isLocalHuman ? 'LINE MONOPOLY!' : `${winnerObj?.name || 'Player'} LINE WIN!`;
    } else if (victoryDetails?.type === 'net_worth_time') {
      titleEl.textContent = isLocalHuman ? 'RICHEST TYCOON!' : `${winnerObj?.name || 'Player'} WON!`;
    } else {
      titleEl.textContent = isLocalHuman ? 'YOU WON!' : `${winnerObj?.name || 'Player'} WON!`;
    }
  }

  const subtitleEl = document.getElementById('victory-subtitle');
  if (subtitleEl) {
    subtitleEl.textContent = victoryDetails?.title || (isLocalHuman ? 'Supreme World Real Estate Tycoon' : 'Master of the Global Board');
  }

  const accoladeTitle = document.getElementById('victory-accolade-title');
  const accoladeDesc = document.getElementById('victory-accolade-desc');
  const accoladeIcon = document.getElementById('victory-accolade-icon');

  if (accoladeTitle) {
    accoladeTitle.textContent = victoryDetails?.title || 'GLOBAL TYCOON SUPREMACY!';
  }
  if (accoladeDesc) {
    accoladeDesc.textContent = victoryDetails?.desc || 'All rival tycoons bankrupted. You rule the entire global real estate empire!';
  }
  if (accoladeIcon) {
    if (victoryDetails?.type === 'triple_monopoly') accoladeIcon.textContent = '🏰';
    else if (victoryDetails?.type === 'line_monopoly') accoladeIcon.textContent = '🌐';
    else if (victoryDetails?.type === 'net_worth_time') accoladeIcon.textContent = '⏱️';
    else accoladeIcon.textContent = '👑';
  }

  const cashEl = document.getElementById('victory-stat-cash');
  if (cashEl && winnerObj) {
    cashEl.textContent = fmtMoney(winnerObj.cash || 0);
  }

  const propsEl = document.getElementById('victory-stat-props');
  if (propsEl && winnerObj) {
    const pIdx = winnerObj.id !== undefined ? winnerObj.id : gameState.players.indexOf(winnerObj);
    const ownedCount = BOARD_TILES.filter(t => gameState.properties[t.id]?.owner === pIdx).length;
    propsEl.textContent = `${ownedCount} Cities`;
  }

  const modal = document.getElementById('modal-victory');
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    renderNetWorthTimelineChart('victory-timeline-chart');
  }

  const card = document.getElementById('victory-card');
  if (card) {
    card.classList.remove('victory-card-animate');
    void card.offsetWidth; // re-flow
    card.classList.add('victory-card-animate');
  }

  // Reset rematch button & multiplayer status indicators
  const statusEl = document.getElementById('victory-multiplayer-status');
  if (statusEl) {
    statusEl.innerHTML = '';
    statusEl.classList.add('hidden');
  }

  const playBtn = document.getElementById('btn-victory-play-again');
  if (playBtn) {
    playBtn.disabled = false;
    playBtn.classList.remove('ring-4', 'ring-amber-300', 'animate-pulse');
  }

  const playBtnText = document.getElementById('btn-victory-play-again-text');
  if (playBtnText) {
    playBtnText.textContent = 'PLAY AGAIN';
  }

  startVictoryCelebration(winnerObj);
}

export function closeAllGameModals() {
  const modalIds = [
    'modal-victory',
    'modal-buy-city',
    'modal-upgrade-city',
    'modal-auction',
    'modal-chance-wheel',
    'modal-tile-inspector',
    'modal-portfolio',
    'modal-trade',
    'modal-incoming-trade',
    'modal-rules',
    'modal-disconnect-notice',
    'modal-setup',
    'modal-monopoly-celebration',
    'modal-confirm-exit-lobby',
    'modal-leaderboard'
  ];
  modalIds.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.classList.add('hidden');
      el.classList.remove('flex');
    }
  });
}

export function handlePlayAgainAction() {
  if (networkState.isMultiplayer && !networkState.isHost) {
    // Guest requests rematch from Room Host
    const myName = (matchSettings.customPlayers[networkState.localPlayerIdx] || {}).name || 'Tycoon Friend';
    broadcastAction('ACTION_REQUEST_PLAY_AGAIN', {
      playerName: myName
    });
    const btnText = document.getElementById('btn-victory-play-again-text');
    if (btnText) btnText.textContent = 'WAITING FOR HOST...';
    const statusEl = document.getElementById('victory-multiplayer-status');
    if (statusEl) {
      statusEl.innerHTML = '<i class="fa-solid fa-hourglass-half fa-spin mr-1"></i> Rematch requested! Waiting for Room Host to start...';
      statusEl.classList.remove('hidden');
    }
    const btn = document.getElementById('btn-victory-play-again');
    if (btn) btn.disabled = true;
    playSFX('hop');
    logEvent('⏳ Rematch requested from Room Host.');
    return;
  }

  // Host or Local Single Player: immediately launch rematch!
  stopVictoryCelebration();
  const modal = document.getElementById('modal-victory');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
  closeAllGameModals();

  if (networkState.isMultiplayer && networkState.isHost) {
    broadcastStartOnlineMatch();
  }

  startIntroCameraFlyIn();
  if (engineCallbacks.startNewMatch) {
    engineCallbacks.startNewMatch();
  } else if (window.startNewMatch) {
    window.startNewMatch();
  }
}

export function handleReturnToLobbyFromVictory() {
  stopVictoryCelebration();
  const modal = document.getElementById('modal-victory');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
  }
  closeAllGameModals();
  gameState.gameStarted = false;

  if (networkState.isMultiplayer) {
    if (networkState.isHost) {
      // Host informs all guests to return to lobby together WITHOUT disconnecting!
      broadcastReturnToLobby();
      logEvent('👑 Table Host brought all room players back to the lobby.');
    } else {
      // Guest notifies host
      broadcastAction('ACTION_GUEST_LOBBY', {
        senderIdx: networkState.localPlayerIdx
      });
      logEvent('🚪 Returned to room lobby.');
    }
  }

  // Open the landing setup screen without leaving the room!
  if (window.openLandingSetupScreen) {
    window.openLandingSetupScreen();
  } else {
    openSetupModal();
  }
}

export function closeVictoryAndPlayAgain() {
  handlePlayAgainAction();
}

/* ─────────────────────────────────────────────────────────────────────────────
   H. SETUP / LOBBY MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openSetupModal() {
  stopVictoryCelebration();
  document.getElementById('modal-victory')?.classList.add('hidden');
  document.getElementById('modal-victory')?.classList.remove('flex');
  renderLobbyControls();
  const m = document.getElementById('modal-setup');
  if (m) {
    m.classList.remove('hidden');
    m.classList.add('flex');
  }
}

export function setLobbyCount(n) {
  setLobbyPlayerCount(n);
  renderLobbyControls();
}

export function renderLobbyControls() {
  [2, 3, 4, 5, 6].forEach(n => {
    const b = document.getElementById(`lobby-cnt-${n}`);
    if (b) {
      b.className = n === lobbyPlayerCount
        ? 'px-3 py-1.5 rounded-xl text-xs font-extrabold bg-indigo-600 text-white cursor-pointer'
        : 'px-3 py-1.5 rounded-xl text-xs font-extrabold bg-slate-200 text-slate-600 cursor-pointer';
    }
  });

  const list = document.getElementById('lobby-players-list');
  if (!list) return;
  list.innerHTML = '';
  for (let i = 0; i < lobbyPlayerCount; i++) {
    const th = PLAYER_THEMES[i];
    list.innerHTML += `
      <div class="flex items-center justify-between bg-slate-50 px-3 py-2 rounded-2xl border border-slate-200">
        <div class="flex items-center gap-2">
          <span class="w-3.5 h-3.5 rounded-full" style="background:${th.colorHex}"></span>
          <input type="text" value="${th.name}" onchange="window.updatePlayerName(${i}, this.value)" class="bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs font-extrabold w-28">
        </div>
        <span class="text-xs font-bold text-slate-500">${i === 0 ? 'Human (YOU)' : 'Smart AI Bot'}</span>
      </div>
    `;
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   H. RULES MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openRulesModal() {
  document.getElementById('modal-rules').classList.remove('hidden');
  document.getElementById('modal-rules').classList.add('flex');
}

export function closeRulesModal() {
  document.getElementById('modal-rules').classList.add('hidden');
  document.getElementById('modal-rules').classList.remove('flex');
}

/* ─────────────────────────────────────────────────────────────────────────────
   I. TOMATO / EMOTES
───────────────────────────────────────────────────────────────────────────── */
let tomatoThrows = 0;
export function throwTomatoAtOpponent() {
  tomatoThrows++;
  const elCounter = document.getElementById('tomato-counter');
  if (elCounter) elCounter.textContent = tomatoThrows;

  const tomato = document.createElement('div');
  tomato.className = 'flying-tomato';
  tomato.textContent = '🍅';
  tomato.style.left = '120px';
  tomato.style.top = '90px';
  document.body.appendChild(tomato);

  requestAnimationFrame(() => {
    tomato.style.left = `${window.innerWidth - 160}px`;
    tomato.style.top = '95px';
    tomato.style.transform = 'rotate(360deg) scale(1.35)';
  });

  setTimeout(() => {
    tomato.textContent = '💥';
    playSFX('hop');
    setTimeout(() => tomato.remove(), 350);
  }, 550);
}

export function toggleEmotePopover() {
  const p = document.getElementById('emote-popover');
  p.classList.toggle('hidden');
  p.classList.toggle('flex');
}

export function sendQuickEmote(text) {
  toggleEmotePopover();
  if (text.includes('🍅')) throwTomatoAtOpponent();
  showSpeechBubble(text, 2500);
}

export function toggleEventLogDrawer() {
  const d = document.getElementById('event-log-drawer');
  d.classList.toggle('hidden');
  d.classList.toggle('flex');
}

/* ─────────────────────────────────────────────────────────────────────────────
   J. MONOPOLY CELEBRATION MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openMonopolyCelebrationModal(playerIdx, groupKey) {
  if (isLobbyScreenActive()) return;
  const p = gameState.players[playerIdx];
  const group = GROUP_META[groupKey];
  if (!p || !group) return;

  const winnerEl = document.getElementById('monopoly-winner-name');
  const groupEl = document.getElementById('monopoly-group-name');
  const headerEl = document.getElementById('monopoly-modal-header');
  const tilesContainer = document.getElementById('monopoly-tiles-list');

  if (winnerEl) winnerEl.textContent = `${p.name} ACHIEVED A MONOPOLY!`;
  if (groupEl) groupEl.textContent = `${group.name} Set Completed`;
  if (headerEl) headerEl.style.background = `linear-gradient(135deg, ${group.hex}, #1e1b4b)`;

  // Filter cities in this group
  const groupTiles = BOARD_TILES.filter(t => t.type === 'city' && t.group === groupKey);

  if (tilesContainer) {
    tilesContainer.innerHTML = groupTiles.map(t => {
      const baseRent = t.rent[0];
      const boostedRent = baseRent * 2;
      return `
        <div class="flex items-center justify-between p-3.5 rounded-2xl border-2 border-slate-200/90 bg-white shadow-xs">
          <div class="flex items-center gap-3">
            <span class="w-4 h-4 rounded-full border-2 border-white shadow-xs flex-shrink-0" style="background:${group.hex}"></span>
            <div>
              <div class="font-display font-extrabold text-base text-slate-900 leading-tight">${t.name}</div>
              <div class="text-xs text-slate-600 font-bold mt-0.5">City Value: ${fmtMoney(t.price)}</div>
            </div>
          </div>
          <div class="text-right">
            <div class="text-sm font-black text-emerald-700">${fmtMoney(boostedRent)} <span class="text-xs font-bold text-emerald-800">/ visit</span></div>
            <div class="text-xs font-black text-amber-700 tracking-wider uppercase mt-0.5">⚡ 2× BOOSTED</div>
          </div>
        </div>
      `;
    }).join('');
  }

  // Play fanfare and burst confetti
  playSFX('win');
  fireConfettiBurst(window.innerWidth / 2, window.innerHeight * 0.45, 120);
  spawnAnimatedReaction('money');

  // Highlight tiles on 3D board
  setMonopolyTileHighlights(groupTiles.map(t => t.id), group.hex);

  // Show modal with bounce animation
  const m = document.getElementById('modal-monopoly-celebration');
  const card = document.getElementById('modal-monopoly-card');
  if (m) {
    m.classList.remove('hidden');
    m.classList.add('flex');
    if (card) {
      setTimeout(() => {
        card.classList.remove('scale-90', 'opacity-0');
        card.classList.add('scale-100', 'opacity-100');
      }, 30);
    }
  }

  logEvent(`👑 <strong>${p.name}</strong> completed the <strong>${group.name}</strong> Monopoly! All cities collect <strong>2× Rent</strong>!`);
}

export function closeMonopolyModal() {
  const m = document.getElementById('modal-monopoly-celebration');
  const card = document.getElementById('modal-monopoly-card');
  if (card) {
    card.classList.remove('scale-100', 'opacity-100');
    card.classList.add('scale-90', 'opacity-0');
  }
  setTimeout(() => {
    if (m) {
      m.classList.add('hidden');
      m.classList.remove('flex');
    }
  }, 250);
}

export function checkAndTriggerMonopoly(playerIdx, groupKey) {
  if (!groupKey) return;
  if (!gameState.achievedMonopolies) gameState.achievedMonopolies = {};

  const key = `${playerIdx}_${groupKey}`;
  if (gameState.achievedMonopolies[key]) return;

  if (ownsFullColorGroup(playerIdx, groupKey)) {
    gameState.achievedMonopolies[key] = true;
    openMonopolyCelebrationModal(playerIdx, groupKey);
    if (networkState.isMultiplayer) {
      broadcastAction('ACTION_MONOPOLY', { playerIdx, groupKey });
    }
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   J. EXIT TO LOBBY CONFIRMATION MODAL
───────────────────────────────────────────────────────────────────────────── */
export function openConfirmExitLobbyModal() {
  const m = document.getElementById('modal-confirm-exit-lobby');
  if (m) {
    m.classList.remove('hidden');
    m.classList.add('flex');
  }
}

export function closeConfirmExitLobbyModal() {
  const m = document.getElementById('modal-confirm-exit-lobby');
  if (m) {
    m.classList.add('hidden');
    m.classList.remove('flex');
  }
}

export function handleLobbyButtonClick() {
  if (gameState && gameState.gameStarted) {
    openConfirmExitLobbyModal();
  } else {
    if (window.openLandingSetupScreen) {
      window.openLandingSetupScreen();
    }
  }
}

export function confirmExitToLobbyAction() {
  closeConfirmExitLobbyModal();
  if (window.terminateMatchAndReturnToLobby) {
    window.terminateMatchAndReturnToLobby();
  } else {
    gameState.gameStarted = false;
    gameState.phase = 'SETUP';
    closeAllGameModals();
    if (window.openLandingSetupScreen) {
      window.openLandingSetupScreen();
    }
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   K. LIVE LEADERBOARD & NET WORTH STANDINGS MODAL
───────────────────────────────────────────────────────────────────────────── */
export function renderLeaderboardModal() {
  const container = document.getElementById('leaderboard-players-list');
  if (!container) return;

  const players = gameState.players || [];
  if (!players.length) {
    container.innerHTML = `<div class="text-center py-8 text-slate-500 font-bold">No active match in progress.</div>`;
    return;
  }

  // Calculate detailed stats for each player
  const standings = players.map((p, idx) => {
    const netWorth = calculatePlayerNetWorth(idx);
    const sets = countCompletedColorGroups(idx);
    const lineMonopoly = checkLineMonopoly(idx);

    let ownedPropsCount = 0;
    let houseCount = 0;
    let propertyAssetVal = 0;
    for (const t of BOARD_TILES) {
      const st = gameState.properties[t.id];
      if (st && st.owner === idx) {
        ownedPropsCount++;
        if (st.mortgaged) {
          propertyAssetVal += (t.price / 2);
        } else {
          propertyAssetVal += t.price;
          if (st.level > 0 && t.houseCost) {
            houseCount += st.level;
            propertyAssetVal += st.level * t.houseCost;
          }
        }
      }
    }

    const theme = PLAYER_THEMES[idx] || { colorHex: '#6c5ce7', name: p.name };
    const isLocal = (idx === (networkState.isMultiplayer ? networkState.localPlayerIdx : 0));

    return {
      player: p,
      idx,
      theme,
      netWorth,
      cash: p.cash,
      sets,
      lineMonopoly,
      ownedPropsCount,
      houseCount,
      propertyAssetVal,
      isLocal,
      bankrupt: !!p.bankrupt,
      inIsland: !!p.inIsland
    };
  });

  // Sort descending by netWorth (bankrupt players at the bottom)
  standings.sort((a, b) => {
    if (a.bankrupt && !b.bankrupt) return 1;
    if (!a.bankrupt && b.bankrupt) return -1;
    return b.netWorth - a.netWorth;
  });

  // Total net worth for wealth market share calculation
  const totalNetWorth = standings.reduce((sum, s) => sum + Math.max(0, s.netWorth), 0) || 1;

  // Update match timer pill in modal header
  const timerBadge = document.getElementById('leaderboard-match-timer');
  if (timerBadge) {
    const durationMins = matchSettings.matchDurationMinutes || 15;
    const elapsedSecs = gameState.matchSeconds || 0;
    const remainingSecs = Math.max(0, (durationMins * 60) - elapsedSecs);
    const remM = Math.floor(remainingSecs / 60);
    const remS = remainingSecs % 60;
    const timeStr = `${String(remM).padStart(2, '0')}:${String(remS).padStart(2, '0')}`;
    timerBadge.textContent = `⏱️ ${timeStr} left (${durationMins}m cap)`;
  }

  // Summary banner (who leads net worth & who is closest to Triple Monopoly)
  const summaryBanner = document.getElementById('leaderboard-summary-banner');
  if (summaryBanner) {
    const leader = standings[0];
    const topSetsPlayer = [...standings].sort((a, b) => b.sets - a.sets)[0];
    const targetSets = matchSettings.monopolySetsToWin || 3;
    summaryBanner.innerHTML = `
      <div class="flex items-center gap-2">
        <span class="text-base">👑</span>
        <span>Wealth Leader: <strong class="text-amber-900">${leader?.player.name || 'None'}</strong> with <strong class="text-emerald-700">${fmtMoney(leader?.netWorth || 0)}</strong></span>
      </div>
      <div class="flex items-center gap-2 text-slate-600">
        <span class="text-base">🏰</span>
        <span>Triple Monopoly Race: <strong class="text-indigo-900">${topSetsPlayer?.player.name || 'None'}</strong> (${topSetsPlayer?.sets || 0}/${targetSets} Sets)</span>
      </div>
    `;
  }

  // Render player cards
  const medals = ['🥇', '🥈', '🥉'];
  container.innerHTML = standings.map((st, rankIdx) => {
    const rank = rankIdx + 1;
    const medal = rank <= 3 ? medals[rank - 1] : `#${rank}`;
    const sharePercent = Math.min(100, Math.max(0, Math.round((st.netWorth / totalNetWorth) * 100)));
    const isLeader = rank === 1 && !st.bankrupt;

    const rankBorder = isLeader
      ? 'border-2 border-amber-400 bg-gradient-to-r from-amber-50/90 via-white to-amber-50/50 shadow-md ring-2 ring-amber-300/40'
      : (st.bankrupt ? 'border border-slate-200 bg-slate-100/70 opacity-60' : 'border border-slate-200 bg-white hover:border-sky-300 shadow-xs');

    return `
      <div class="rounded-2xl p-3.5 sm:p-4 transition ${rankBorder}">
        <div class="flex items-center justify-between gap-3">
          
          <!-- Left: Rank & Avatar & Name -->
          <div class="flex items-center gap-3 min-w-0 flex-1">
            <div class="w-8 h-8 rounded-full ${isLeader ? 'bg-amber-400 text-slate-950 font-black' : 'bg-slate-100 text-slate-700 font-bold'} flex items-center justify-center text-sm shadow-xs flex-shrink-0">
              ${medal}
            </div>
            
            <div class="w-10 h-10 rounded-full border-2 border-white shadow-sm flex items-center justify-center font-black text-white text-sm flex-shrink-0" style="background:${st.theme.colorHex}">
              ${(st.player.name || 'P')[0].toUpperCase()}
            </div>

            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-1.5 flex-wrap">
                <span class="font-black text-sm sm:text-base text-slate-900 truncate uppercase">${st.player.name}</span>
                ${st.isLocal ? '<span class="text-[10px] font-black bg-sky-500 text-white px-2 py-0.5 rounded-full shadow-2xs">YOU</span>' : ''}
                ${st.player.isAI ? '<span class="text-[10px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-md border border-slate-200">BOT</span>' : ''}
                ${st.inIsland ? '<span class="text-[10px] font-black bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-md border border-amber-300">🏝️ ISLAND</span>' : ''}
                ${st.bankrupt ? '<span class="text-[10px] font-black bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded-md border border-rose-300">BANKRUPT</span>' : ''}
                ${st.lineMonopoly > 0 ? '<span class="text-[10px] font-black bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-md border border-emerald-300">👑 EDGE WIN</span>' : ''}
              </div>
              <div class="text-xs text-slate-500 font-semibold flex items-center gap-2 mt-0.5 flex-wrap">
                <span>💵 Cash: <strong class="text-slate-800 font-bold">${st.bankrupt ? '$0' : fmtMoney(st.cash)}</strong></span>
                <span>•</span>
                <span>🏙️ Properties: <strong class="text-slate-800 font-bold">${st.ownedPropsCount} (${st.houseCount} 🏠)</strong></span>
                <span>•</span>
                <span>🏰 Monopolies: <strong class="text-indigo-700 font-bold">${st.sets}/3</strong></span>
              </div>
            </div>
          </div>

          <!-- Right: Total Net Worth Badge -->
          <div class="text-right flex-shrink-0">
            <div class="text-[10px] font-black uppercase text-slate-400 tracking-wider">NET WORTH</div>
            <div class="font-display font-black text-base sm:text-lg ${isLeader ? 'text-amber-600' : 'text-slate-900'} leading-tight">
              ${st.bankrupt ? '<span class="text-rose-500 font-bold text-sm">ELIMINATED</span>' : fmtMoney(st.netWorth)}
            </div>
            <div class="text-[10px] font-extrabold text-slate-500 mt-0.5">
              ${st.bankrupt ? '0% share' : `${sharePercent}% wealth share`}
            </div>
          </div>

        </div>

        <!-- Wealth Market Share Bar -->
        ${!st.bankrupt ? `
        <div class="mt-2.5 pt-2 border-t border-slate-100 flex items-center gap-2">
          <div class="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
            <div class="h-full rounded-full transition-[width] duration-500" style="width: ${sharePercent}%; background:${st.theme.colorHex}"></div>
          </div>
          <span class="text-[10px] font-bold text-slate-400 tabular-nums">${sharePercent}%</span>
        </div>
        ` : ''}

      </div>
    `;
  }).join('');

  // Render post-match / in-match net worth timeline chart
  renderNetWorthTimelineChart('leaderboard-timeline-chart');
}

export function openLeaderboardModal() {
  if (isLobbyScreenActive()) return;
  renderLeaderboardModal();
  const m = document.getElementById('modal-leaderboard');
  if (m) {
    m.classList.remove('hidden');
    m.classList.add('flex');
    playSFX('hop');
  }
}

export function closeLeaderboardModal() {
  const m = document.getElementById('modal-leaderboard');
  if (m) {
    m.classList.add('hidden');
    m.classList.remove('flex');
  }
}

export function toggleLeaderboardModal() {
  const m = document.getElementById('modal-leaderboard');
  if (m && !m.classList.contains('hidden')) {
    closeLeaderboardModal();
  } else {
    openLeaderboardModal();
  }
}

/**
 * Renders an SVG multi-line Net Worth timeline chart.
 * Uses PLAYER_THEMES and reactive gameState.netWorthHistory.
 */
export function renderNetWorthTimelineChart(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const history = gameState.netWorthHistory || [];
  const players = gameState.players || [];

  if (players.length === 0) {
    container.innerHTML = '<div class="text-xs text-slate-400 font-bold text-center py-4">No match timeline data recorded</div>';
    return;
  }

  // Ensure at least two timeline data points
  let dataPoints = history.length > 0 ? [...history] : [];
  if (dataPoints.length === 0) {
    const initialVals = players.map(p => calculatePlayerNetWorth(p.id !== undefined ? p.id : players.indexOf(p)));
    dataPoints = [
      { turn: 0, values: initialVals },
      { turn: 1, values: initialVals }
    ];
  } else if (dataPoints.length === 1) {
    dataPoints.push({
      turn: dataPoints[0].turn + 1,
      values: [...dataPoints[0].values]
    });
  }

  // Calculate dynamic boundaries
  let minVal = Infinity;
  let maxVal = -Infinity;
  dataPoints.forEach(pt => {
    (pt.values || []).forEach(v => {
      if (v < minVal) minVal = v;
      if (v > maxVal) maxVal = v;
    });
  });

  if (minVal === Infinity || maxVal === -Infinity) {
    minVal = 0;
    maxVal = 3000000;
  }

  minVal = Math.max(0, Math.floor(minVal * 0.9));
  maxVal = Math.ceil(maxVal * 1.1);
  if (maxVal <= minVal) maxVal = minVal + 1000000;

  const width = 480;
  const height = 120;
  const padLeft = 52;
  const padRight = 16;
  const padTop = 14;
  const padBottom = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  // Horizontal Grid Lines & Formatted Values
  const gridSteps = 3;
  let gridSvg = '';
  for (let g = 0; g <= gridSteps; g++) {
    const fraction = g / gridSteps;
    const yVal = minVal + fraction * (maxVal - minVal);
    const yPos = padTop + plotH - (fraction * plotH);
    gridSvg += `
      <line x1="${padLeft}" y1="${yPos.toFixed(1)}" x2="${(width - padRight).toFixed(1)}" y2="${yPos.toFixed(1)}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3,3" />
      <text x="${padLeft - 6}" y="${(yPos + 3).toFixed(1)}" text-anchor="end" font-size="8" font-weight="700" fill="#94a3b8">${fmtMoney(yVal)}</text>
    `;
  }

  // Draw Line Paths per player
  let linesSvg = '';
  let legendHtml = '';

  players.forEach((p, pIdx) => {
    if (!p) return;
    const theme = PLAYER_THEMES[pIdx] || {};
    const color = theme.colorHex || p.colorHex || '#3b82f6';

    const coords = dataPoints.map((pt, i) => {
      const x = padLeft + (i / (dataPoints.length - 1)) * plotW;
      const val = pt.values && pt.values[pIdx] !== undefined ? pt.values[pIdx] : 0;
      const y = padTop + plotH - ((val - minVal) / (maxVal - minVal)) * plotH;
      return { x, y, val };
    });

    const pathD = coords.map((c, i) => (i === 0 ? `M ${c.x.toFixed(1)} ${c.y.toFixed(1)}` : `L ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)).join(' ');
    const lastCoord = coords[coords.length - 1];

    linesSvg += `
      <path d="${pathD}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" opacity="${p.bankrupt ? '0.35' : '0.95'}" />
      <circle cx="${lastCoord.x.toFixed(1)}" cy="${lastCoord.y.toFixed(1)}" r="3" fill="${color}" stroke="#ffffff" stroke-width="1.5" />
    `;

    legendHtml += `
      <div class="flex items-center gap-1.5 text-[10px] font-bold text-slate-700">
        <span class="w-2.5 h-2.5 rounded-full flex-shrink-0" style="background:${color}"></span>
        <span class="truncate max-w-[65px] uppercase">${p.name}</span>
        <span class="text-slate-400 font-semibold">${fmtMoney(lastCoord.val)}</span>
      </div>
    `;
  });

  container.innerHTML = `
    <div class="w-full flex flex-col items-center">
      <svg viewBox="0 0 ${width} ${height}" class="w-full h-auto max-h-28 overflow-visible">
        ${gridSvg}
        ${linesSvg}
      </svg>
      <div class="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 mt-1 px-1 border-t border-slate-100 pt-1 w-full">
        ${legendHtml}
      </div>
    </div>
  `;
}

