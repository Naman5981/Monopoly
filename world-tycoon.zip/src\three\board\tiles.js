/**
 * three/board/tiles.js
 * Board tile blocks:
 * - Canvas 2D texture generation for city deeds, colors, rents, and flags.
 * - Procedural bevel borders and illuminated glass frames.
 * - Building group placement and dynamic upgrade tier switching (Flag, Cottages, Skyscrapers).
 */

import * as THREE from 'three';
import { context } from '../core/context.js';
import { BOARD_TILES, GROUP_META, PLAYER_THEMES } from '../../game/data.js';
import { gameState, matchSettings } from '../../game/state.js';
import { fmtMoney } from '../../game/utils.js';
import { calculateTileRent } from '../../game/rules.js';
import { getTileWorldPosition, BASE_TILE_Y, BASE_BUILDING_Y } from './coords.js';
import { currentBulbMode, getLightPlayerAccent, getGroundPoolTexture } from '../core/lighting.js';
import {
  createDetailedFlagMesh,
  createDetailedHouseMesh,
  createDetailedSkyscraperMesh,
  animatedBuildingPopups
} from '../assets/buildings.js';
import { disposeHierarchy } from '../core/dispose.js';
import { updateDioramaCenterForEdition } from './diorama.js';

/**
 * Renders an offscreen canvas texture for a specific tile.
 * @param {object} tile - Tile definition object
 * @param {object} propState - Dynamic property ownership and mortgage state
 * @returns {THREE.CanvasTexture}
 */
export function createTileTexture(tile, propState) {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 512;
  const ctx = c.getContext('2d');

  const boardStyle = matchSettings.boardStyle || 'wood';
  const isCyber = (boardStyle === 'cyberpunk');
  const isElegant = (boardStyle === 'elegant');

  // Background fill
  if (isCyber) {
    ctx.fillStyle = propState?.mortgaged ? '#0e1726' : '#080d1a';
  } else if (isElegant) {
    ctx.fillStyle = propState?.mortgaged ? '#f1f5f9' : '#fafaf9';
  } else {
    ctx.fillStyle = propState?.mortgaged ? '#e2e8f0' : '#ffffff';
  }
  ctx.fillRect(0, 0, 512, 512);

  const isOwned = propState?.owner !== null && propState?.owner !== undefined && gameState.players[propState.owner];
  const ownerTheme = isOwned ? PLAYER_THEMES[propState.owner] : null;
  const ownerName = isOwned ? (gameState.players[propState.owner]?.name || 'PLAYER').toUpperCase() : '';

  if (isOwned) {
    // Bold outer frame in owner's true theme color (increased from 18 to 26px for crisp distance glanceability)
    ctx.strokeStyle = ownerTheme.colorHex;
    ctx.lineWidth = 26;
    ctx.strokeRect(13, 13, 486, 486);

    // Inner crisp contrast pinstripe separating owner color from group header and sidewalk
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.95)';
    ctx.lineWidth = 3.5;
    ctx.strokeRect(27, 27, 458, 458);

    ctx.fillStyle = isCyber ? 'rgba(0, 245, 255, 0.25)' : (isElegant ? 'rgba(212, 175, 55, 0.25)' : 'rgba(255, 255, 255, 0.90)');
    ctx.fillRect(29, 29, 454, 6);
    ctx.fillRect(29, 29, 6, 454);

    ctx.fillStyle = isCyber ? 'rgba(0, 0, 0, 0.6)' : 'rgba(15, 23, 42, 0.22)';
    ctx.fillRect(29, 477, 454, 6);
    ctx.fillRect(477, 29, 6, 454);
  } else {
    if (isCyber) {
      ctx.strokeStyle = '#00f5ff';
      ctx.lineWidth = 10;
      ctx.strokeRect(7, 7, 498, 498);

      ctx.strokeStyle = '#d946ef';
      ctx.lineWidth = 3;
      ctx.strokeRect(16, 16, 480, 480);
    } else if (isElegant) {
      ctx.strokeStyle = '#d4af37';
      ctx.lineWidth = 12;
      ctx.strokeRect(7, 7, 498, 498);

      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 3;
      ctx.strokeRect(16, 16, 480, 480);
    } else {
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 14;
      ctx.strokeRect(7, 7, 498, 498);

      ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
      ctx.fillRect(14, 14, 484, 8);
      ctx.fillRect(14, 14, 8, 484);

      ctx.fillStyle = 'rgba(15, 23, 42, 0.28)';
      ctx.fillRect(14, 490, 484, 8);
      ctx.fillRect(490, 14, 8, 484);

      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 4;
      ctx.strokeRect(20, 20, 472, 472);
    }
  }

  const pos = getTileWorldPosition(tile.id);
  ctx.save();
  ctx.translate(256, 256);
  if (pos.side === 1) ctx.rotate(Math.PI / 2);
  if (pos.side === 2) ctx.rotate(Math.PI);
  if (pos.side === 3) ctx.rotate(-Math.PI / 2);
  ctx.translate(-256, -256);

  if (tile.type === 'city' && tile.group) {
    // 1. Group color header bar
    ctx.fillStyle = GROUP_META[tile.group].hex;
    ctx.fillRect(16, 16, 480, 72);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
    ctx.fillRect(16, 16, 480, 8);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(16, 88, 480, 4);
  }

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  function fillRoundRect(x, y, w, h, r, fillStyle, strokeStyle = null, lineWidth = 0) {
    ctx.save();
    ctx.fillStyle = fillStyle;
    if (ctx.roundRect) {
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r);
      ctx.fill();
      if (strokeStyle && lineWidth > 0) {
        ctx.strokeStyle = strokeStyle;
        ctx.lineWidth = lineWidth;
        ctx.stroke();
      }
    } else {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
      ctx.fill();
      if (strokeStyle && lineWidth > 0) {
        ctx.strokeStyle = strokeStyle;
        ctx.lineWidth = lineWidth;
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  if (tile.type === 'city') {
    // -------------------------------------------------------------------------
    // ZONE 1: HERO CITY NAME (y: 96 to 176, center: 136)
    // -------------------------------------------------------------------------
    const nameLen = tile.name.length;
    const fontSize = nameLen <= 6 ? 64 : (nameLen <= 9 ? 54 : (nameLen <= 11 ? 46 : 40));
    ctx.font = `900 ${fontSize}px Rubik, system-ui, sans-serif`;
    ctx.fillStyle = isCyber ? '#ffffff' : '#0f172a';
    ctx.fillText(tile.name, 256, 136);

    // -------------------------------------------------------------------------
    // ZONE 2: HOUSE / BUILDING PROGRESSION TRACK (y: 180 to 280)
    // -------------------------------------------------------------------------
    const lvl = propState?.level || 0;

    if (isOwned) {
      // 2A. Owner Plaque Banner (y: 180..226, h: 46)
      ctx.save();
      ctx.shadowColor = 'rgba(0, 0, 0, 0.24)';
      ctx.shadowBlur = 8;
      ctx.shadowOffsetY = 2;
      fillRoundRect(36, 180, 440, 46, 14, ownerTheme.colorHex, '#ffffff', 2);
      ctx.shadowColor = 'transparent';
      ctx.font = '800 24px Rubik, system-ui, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`👑 ${ownerName}`, 256, 203);
      ctx.restore();

      // 2B. House Upgrade Track (4 Tier Slots across 440px: 36, 148, 260, 372)
      for (let i = 0; i < 3; i++) {
        const slotX = 36 + i * 112;
        const isActive = lvl >= i + 1;
        if (isActive) {
          fillRoundRect(slotX, 236, 104, 42, 10, '#10b981', '#ffffff', 2);
          ctx.font = '800 19px Rubik, system-ui, sans-serif';
          ctx.fillStyle = '#ffffff';
          ctx.fillText(`🏠 H${i + 1}`, slotX + 52, 257);
        } else {
          fillRoundRect(
            slotX,
            236,
            104,
            42,
            10,
            isCyber ? 'rgba(255, 255, 255, 0.06)' : '#f1f5f9',
            isCyber ? 'rgba(255, 255, 255, 0.16)' : '#cbd5e1',
            1.5
          );
          ctx.font = '700 18px Rubik, system-ui, sans-serif';
          ctx.fillStyle = isCyber ? '#64748b' : '#94a3b8';
          ctx.fillText('🏠', slotX + 52, 257);
        }
      }

      // Slot 4: Skyscraper / Landmark
      const skyX = 372;
      const isSkyActive = lvl >= 4;
      if (isSkyActive) {
        fillRoundRect(skyX, 236, 104, 42, 10, '#8b5cf6', '#ffffff', 2);
        ctx.font = '900 19px Rubik, system-ui, sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.fillText('🏢 SKY', skyX + 52, 257);
      } else {
        fillRoundRect(
          skyX,
          236,
          104,
          42,
          10,
          isCyber ? 'rgba(255, 255, 255, 0.06)' : '#f1f5f9',
          isCyber ? 'rgba(255, 255, 255, 0.16)' : '#cbd5e1',
          1.5
        );
        ctx.font = '700 18px Rubik, system-ui, sans-serif';
        ctx.fillStyle = isCyber ? '#64748b' : '#94a3b8';
        ctx.fillText('🏢', skyX + 52, 257);
      }
    } else {
      // 2C. Unowned: House Potential & Build Cost Container (y: 180..278, h: 98)
      fillRoundRect(
        36,
        180,
        440,
        98,
        16,
        isCyber ? 'rgba(15, 23, 42, 0.75)' : '#f8fafc',
        isCyber ? '#1e293b' : '#e2e8f0',
        2
      );

      // Header: Build House Cost
      ctx.font = '800 22px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#0284c7';
      ctx.fillText(`🏗️ BUILD HOUSE: +${fmtMoney(tile.houseCost || 0)}`, 256, 207);

      // 4 Preview Tier Slots
      const previewPills = ['🏠 H1', '🏠 H2', '🏠 H3', '🏢 SKY'];
      for (let i = 0; i < 4; i++) {
        const pX = 52 + i * 104;
        fillRoundRect(
          pX,
          234,
          96,
          32,
          8,
          isCyber ? 'rgba(30, 41, 59, 0.65)' : '#e2e8f0',
          isCyber ? '#334155' : '#cbd5e1',
          1
        );
        ctx.font = '800 15px Rubik, system-ui, sans-serif';
        ctx.fillStyle = isCyber ? '#94a3b8' : '#475569';
        ctx.fillText(previewPills[i], pX + 48, 250);
      }
    }

    // -------------------------------------------------------------------------
    // ZONE 3: RENT & PRICE SHOWCASE (y: 288 to 494)
    // -------------------------------------------------------------------------
    if (isOwned) {
      const rentAmt = propState?.mortgaged ? 0 : calculateTileRent(tile.id);

      ctx.font = '800 22px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#047857';
      ctx.fillText('CURRENT RENT', 256, 314);

      const rentStr = fmtMoney(rentAmt);
      const rentFontSize = rentStr.length > 8 ? 72 : 84;
      ctx.font = `900 ${rentFontSize}px Rubik, system-ui, sans-serif`;
      ctx.fillStyle = isCyber ? '#38bdf8' : '#047857';
      ctx.fillText(rentStr, 256, 382);

      // Footer Status Pill
      if (propState?.festivalBoost) {
        fillRoundRect(
          36,
          436,
          440,
          50,
          14,
          isCyber ? 'rgba(236, 72, 153, 0.22)' : '#fdf2f8',
          '#ec4899',
          2
        );
        ctx.font = '800 21px Rubik, system-ui, sans-serif';
        ctx.fillStyle = '#db2777';
        ctx.fillText('★ FESTIVAL 2X RENT ACTIVE ★', 256, 461);
      } else if (propState?.mortgaged) {
        fillRoundRect(36, 436, 440, 50, 14, '#fef2f2', '#ef4444', 2);
        ctx.font = '800 21px Rubik, system-ui, sans-serif';
        ctx.fillStyle = '#dc2626';
        ctx.fillText('MORTGAGED — NO RENT', 256, 461);
      } else if (lvl === 4) {
        fillRoundRect(
          36,
          436,
          440,
          50,
          14,
          isCyber ? 'rgba(168, 85, 247, 0.22)' : '#faf5ff',
          '#a855f7',
          2
        );
        ctx.font = '800 21px Rubik, system-ui, sans-serif';
        ctx.fillStyle = '#7c3aed';
        ctx.fillText('★ MAX LEVEL SKYSCRAPER ★', 256, 461);
      } else {
        fillRoundRect(
          36,
          436,
          440,
          50,
          14,
          isCyber ? 'rgba(30, 41, 59, 0.7)' : '#f1f5f9',
          isCyber ? '#334155' : '#cbd5e1',
          1.5
        );
        ctx.font = '800 21px Rubik, system-ui, sans-serif';
        ctx.fillStyle = isCyber ? '#94a3b8' : '#475569';
        ctx.fillText(`TIER ${lvl} OF 4 HOUSES`, 256, 461);
      }
    } else {
      ctx.font = '800 22px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#94a3b8' : '#64748b';
      ctx.fillText('PURCHASE PRICE', 256, 310);

      const priceStr = fmtMoney(tile.price);
      const priceFontSize = priceStr.length > 8 ? 74 : 86;
      ctx.font = `900 ${priceFontSize}px Rubik, system-ui, sans-serif`;
      ctx.fillStyle = isCyber ? '#00f5ff' : '#0f172a';
      ctx.fillText(priceStr, 256, 376);

      // Base Rent & ROI Pill
      fillRoundRect(
        36,
        432,
        440,
        54,
        16,
        isCyber ? 'rgba(30, 41, 59, 0.85)' : '#f1f5f9',
        isCyber ? '#334155' : '#cbd5e1',
        2
      );
      ctx.font = '800 24px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#0f172a';
      ctx.fillText(`BASE RENT: ${fmtMoney(tile.rent?.[0] || 0)}`, 256, 459);
    }
  } else if (tile.type === 'chance') {
    const colors = ['#ef4444', '#facc15', '#22c55e', '#38bdf8', '#a855f7', '#fb923c'];
    const cx2 = 256, cy2 = 200, r = 110;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(cx2, cy2);
      ctx.arc(cx2, cy2, r, (i * Math.PI) / 3, ((i + 1) * Math.PI) / 3);
      ctx.closePath();
      ctx.fillStyle = colors[i];
      ctx.fill();
      ctx.strokeStyle = isCyber ? '#00f5ff' : '#ffffff';
      ctx.lineWidth = 4;
      ctx.stroke();
    }
    ctx.fillStyle = isCyber ? '#ffffff' : '#0f172a';
    ctx.font = '900 52px Rubik, system-ui, sans-serif';
    ctx.fillText('CHANCE', 256, 405);
  } else if (tile.type === 'tax') {
    ctx.fillStyle = isCyber ? '#111827' : '#f1f5f9';
    ctx.strokeStyle = isCyber ? '#ec4899' : '#64748b';
    ctx.lineWidth = 6;
    ctx.fillRect(166, 70, 180, 190);
    ctx.strokeRect(166, 70, 180, 190);
    ctx.fillStyle = '#dc2626';
    ctx.font = '900 80px Rubik, system-ui, sans-serif';
    ctx.fillText('%', 256, 170);
    ctx.fillStyle = isCyber ? '#ffffff' : '#0f172a';
    ctx.font = '900 56px Rubik, system-ui, sans-serif';
    ctx.fillText('TAX', 256, 345);
    ctx.font = '800 46px Rubik, system-ui, sans-serif';
    ctx.fillStyle = '#dc2626';
    ctx.fillText(`-${fmtMoney(tile.amount)}`, 256, 425);
  } else if (tile.type === 'resort') {
    ctx.fillStyle = '#0ea5e9';
    ctx.fillRect(16, 16, 480, 68);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.32)';
    ctx.fillRect(16, 16, 480, 8);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(16, 84, 480, 4);

    ctx.fillStyle = '#ffffff';
    ctx.font = '900 32px Rubik, system-ui, sans-serif';
    ctx.fillText('RESORT', 256, 50);

    const resortFontSize = tile.name.length > 8 ? 44 : 54;
    ctx.fillStyle = isCyber ? '#ffffff' : '#0f172a';
    ctx.font = `900 ${resortFontSize}px Rubik, system-ui, sans-serif`;
    ctx.fillText(tile.name, 256, 136);

    if (isOwned) {
      // Owner Plaque
      ctx.save();
      ctx.shadowColor = 'rgba(0, 0, 0, 0.24)';
      ctx.shadowBlur = 8;
      ctx.shadowOffsetY = 2;
      fillRoundRect(36, 180, 440, 46, 14, ownerTheme.colorHex, '#ffffff', 2);
      ctx.shadowColor = 'transparent';
      ctx.font = '800 24px Rubik, system-ui, sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`👑 ${ownerName}`, 256, 203);
      ctx.restore();

      // Multiplier feature pill
      fillRoundRect(
        36,
        236,
        440,
        42,
        10,
        isCyber ? 'rgba(30, 41, 59, 0.65)' : '#f1f5f9',
        isCyber ? '#334155' : '#cbd5e1',
        1.5
      );
      ctx.font = '800 18px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#0284c7';
      ctx.fillText('🏝️ VACATION MULTIPLIER (1X–5X)', 256, 257);

      // Rent
      const rentAmt = propState?.mortgaged ? 0 : calculateTileRent(tile.id);
      ctx.font = '800 22px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#047857';
      ctx.fillText('RESORT RENT', 256, 314);

      const rentStr = fmtMoney(rentAmt);
      const rentFontSize = rentStr.length > 8 ? 72 : 84;
      ctx.font = `900 ${rentFontSize}px Rubik, system-ui, sans-serif`;
      ctx.fillStyle = isCyber ? '#38bdf8' : '#047857';
      ctx.fillText(rentStr, 256, 382);

      // Status pill
      fillRoundRect(
        36,
        436,
        440,
        50,
        14,
        isCyber ? 'rgba(30, 41, 59, 0.7)' : '#f1f5f9',
        isCyber ? '#334155' : '#cbd5e1',
        1.5
      );
      ctx.font = '800 21px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#94a3b8' : '#475569';
      ctx.fillText('★ SCALES WITH OWNED RESORTS ★', 256, 461);
    } else {
      // Unowned Resort feature box
      fillRoundRect(
        36,
        180,
        440,
        98,
        16,
        isCyber ? 'rgba(15, 23, 42, 0.75)' : '#f8fafc',
        isCyber ? '#1e293b' : '#e2e8f0',
        2
      );
      ctx.font = '800 22px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#0284c7';
      ctx.fillText('🏝️ VACATION DESTINATION', 256, 207);

      ctx.font = '800 18px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#94a3b8' : '#64748b';
      ctx.fillText('RENT MULTIPLIER: 1X → 2X → 4X → 8X', 256, 248);

      // Price
      ctx.font = '800 22px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#94a3b8' : '#64748b';
      ctx.fillText('PURCHASE PRICE', 256, 310);

      const priceStr = fmtMoney(tile.price);
      const priceFontSize = priceStr.length > 8 ? 74 : 86;
      ctx.font = `900 ${priceFontSize}px Rubik, system-ui, sans-serif`;
      ctx.fillStyle = isCyber ? '#00f5ff' : '#0f172a';
      ctx.fillText(priceStr, 256, 376);

      // Base Rent Pill
      fillRoundRect(
        36,
        432,
        440,
        54,
        16,
        isCyber ? 'rgba(30, 41, 59, 0.85)' : '#f1f5f9',
        isCyber ? '#334155' : '#cbd5e1',
        2
      );
      ctx.font = '800 24px Rubik, system-ui, sans-serif';
      ctx.fillStyle = isCyber ? '#38bdf8' : '#0f172a';
      ctx.fillText(`BASE RENT: ${fmtMoney(tile.rent?.[0] || 0)}`, 256, 459);
    }
  } else {
    ctx.fillStyle = isCyber ? '#ffffff' : '#0f172a';
    ctx.font = '900 52px Rubik, system-ui, sans-serif';
    ctx.fillText(tile.name, 256, 395);
    ctx.fillStyle = isCyber ? '#94a3b8' : '#334155';
    ctx.font = '800 32px Rubik, system-ui, sans-serif';
    ctx.fillText(tile.subtitle || '', 256, 452);
  }

  if (propState?.mortgaged) {
    ctx.fillStyle = 'rgba(225, 29, 72, 0.94)';
    ctx.fillRect(26, 215, 460, 92);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 5;
    ctx.strokeRect(26, 215, 460, 92);
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 50px Rubik, system-ui, sans-serif';
    ctx.fillText('MORTGAGED', 256, 262);
  }

  ctx.restore();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = context.maxAnisotropy;
  tex.needsUpdate = true;
  return tex;
}

export function createTileBorderFrame(colorHex) {
  const frameGroup = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(colorHex),
    emissive: new THREE.Color(colorHex),
    emissiveIntensity: 0.30,
    roughness: 0.28,
    metalness: 0.35,
    transparent: true,
    opacity: 0.96
  });

  const rimW = 2.96;
  const rimThick = 0.14;
  const rimH = 0.045;

  const barNSGeo = new THREE.BoxGeometry(rimW, rimH, rimThick);
  const barN = new THREE.Mesh(barNSGeo, mat);
  barN.position.set(0, 0.125, -(rimW - rimThick) / 2);
  const barS = new THREE.Mesh(barNSGeo, mat);
  barS.position.set(0, 0.125, (rimW - rimThick) / 2);

  const barEWGeo = new THREE.BoxGeometry(rimThick, rimH, rimW - rimThick * 2);
  const barE = new THREE.Mesh(barEWGeo, mat);
  barE.position.set((rimW - rimThick) / 2, 0.125, 0);
  const barW = new THREE.Mesh(barEWGeo, mat);
  barW.position.set(-(rimW - rimThick) / 2, 0.125, 0);

  frameGroup.add(barN, barS, barE, barW);
  frameGroup.userData = { borderMat: mat };
  return frameGroup;
}

export function buildAllBoardTiles3D(boardGroup) {
  context.tilesMeshMap = {};
  context.tileBuildingGroups = {};
  context.activeTileDepressions = {};
  context.tileGroundLightPools = {};
  context.activeTileIlluminations = {};
  context.tileBorderFrames = {};

  BOARD_TILES.forEach(tile => {
    const pos = getTileWorldPosition(tile.id);
    const propState = gameState.properties[tile.id] || null;
    const isOwned = propState?.owner !== null && propState?.owner !== undefined && gameState.players[propState.owner];
    const ownerTheme = isOwned ? PLAYER_THEMES[propState.owner] : null;
    const lightPlayerAccent = ownerTheme ? getLightPlayerAccent(ownerTheme.colorHex, 0.40) : null;
    const boardStyle = matchSettings.boardStyle || 'wood';
    const isCyber = (boardStyle === 'cyberpunk');
    const isElegant = (boardStyle === 'elegant');

    const sideColor = isOwned
      ? new THREE.Color(ownerTheme.colorHex)
      : (isCyber ? new THREE.Color(0x0b1220) : (isElegant ? new THREE.Color(0xfafaf9) : new THREE.Color(0xe2e8f0)));

    const sideMat = new THREE.MeshStandardMaterial({
      color: sideColor,
      roughness: isCyber ? 0.28 : (isElegant ? 0.18 : 0.42),
      metalness: isCyber ? 0.85 : (isElegant ? 0.25 : 0.04)
    });
    const topTex = createTileTexture(tile, propState);
    const topMat = new THREE.MeshStandardMaterial({
      map: topTex,
      color: 0xffffff,
      roughness: isCyber ? 0.20 : (isElegant ? 0.15 : 0.28),
      metalness: isCyber ? 0.15 : (isElegant ? 0.08 : 0.02)
    });
    const materials = [sideMat, sideMat, topMat, sideMat, sideMat, sideMat];
    const tileMesh = new THREE.Mesh(new THREE.BoxGeometry(2.96, 0.24, 2.96), materials);
    tileMesh.position.set(pos.x, BASE_TILE_Y, pos.z);
    tileMesh.receiveShadow = true;
    tileMesh.castShadow = true;
    tileMesh.userData = { tileId: tile.id, topMat, sideMat };

    const borderFrame = createTileBorderFrame(ownerTheme ? ownerTheme.colorHex : '#e2e8f0');
    borderFrame.visible = !!isOwned;
    tileMesh.add(borderFrame);
    context.tileBorderFrames[tile.id] = borderFrame;

    boardGroup.add(tileMesh);
    context.tilesMeshMap[tile.id] = tileMesh;

    const poolGeo = new THREE.PlaneGeometry(4.8, 4.8);
    const poolMat = new THREE.MeshBasicMaterial({
      map: getGroundPoolTexture(),
      color: ownerTheme ? new THREE.Color(ownerTheme.colorHex) : 0xffeedd,
      transparent: true,
      opacity: isOwned ? 0.26 : 0.0,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false
    });
    const groundPool = new THREE.Mesh(poolGeo, poolMat);
    groundPool.rotation.x = -Math.PI / 2;
    groundPool.position.set(pos.x, 0.04, pos.z);
    groundPool.visible = !!isOwned;
    boardGroup.add(groundPool);
    context.tileGroundLightPools[tile.id] = groundPool;

    const bGroup = new THREE.Group();
    bGroup.position.set(pos.x, BASE_BUILDING_Y, pos.z);
    if (pos.side === 1) bGroup.rotation.y = -Math.PI / 2;
    else if (pos.side === 2) bGroup.rotation.y = Math.PI;
    else if (pos.side === 3) bGroup.rotation.y = Math.PI / 2;
    bGroup.userData = { tileId: tile.id };
    boardGroup.add(bGroup);
    context.tileBuildingGroups[tile.id] = bGroup;
    context.activeTileDepressions[tile.id] = { currentOffset: 0, targetOffset: 0 };
    context.activeTileIlluminations[tile.id] = { currentIllum: 0 };
  });

  if (!context.tilePressPointLight) {
    context.tilePressPointLight = new THREE.PointLight(0xffeedd, 0, 7.5, 1.8);
    context.tilePressPointLight.position.set(0, 1.2, 0);
    context.tilePressPointLight.visible = false;
    boardGroup.add(context.tilePressPointLight);
  }
}

/**
 * Updates an individual tile's 2D canvas texture and placed 3D building model (Flag / House / Skyscraper).
 * @param {number} tileId
 */
export function refreshTileTextureAndBuildings(tileId) {
  const tile = BOARD_TILES[tileId];
  const mesh = context.tilesMeshMap[tileId];
  if (!tile || !mesh) return;

  const propState = gameState.properties[tileId] || null;
  const newTex = createTileTexture(tile, propState);
  if (Array.isArray(mesh.material) && mesh.material[2]) {
    if (mesh.material[2].map) mesh.material[2].map.dispose();
    mesh.material[2].map = newTex;
    mesh.material[2].needsUpdate = true;
  }

  const isOwned = propState?.owner !== null && propState?.owner !== undefined && gameState.players[propState.owner];
  const ownerTheme = isOwned ? PLAYER_THEMES[propState.owner] : null;
  const lightPlayerAccent = ownerTheme ? getLightPlayerAccent(ownerTheme.colorHex, 0.40) : null;

  const boardStyle = matchSettings.boardStyle || 'wood';
  const isCyber = (boardStyle === 'cyberpunk');
  const isElegant = (boardStyle === 'elegant');

  const sideColor = isOwned
    ? new THREE.Color(ownerTheme.colorHex)
    : (isCyber ? new THREE.Color(0x0b1220) : (isElegant ? new THREE.Color(0xfafaf9) : new THREE.Color(0xe2e8f0)));

  const isNight = (currentBulbMode === 'night');
  const isSunset = (currentBulbMode === 'sunset');

  if (Array.isArray(mesh.material)) {
    [0, 1, 3, 4, 5].forEach(idx => {
      if (mesh.material[idx]) {
        mesh.material[idx].color.copy(sideColor);
        mesh.material[idx].roughness = isCyber ? 0.28 : (isElegant ? 0.18 : 0.42);
        mesh.material[idx].metalness = isCyber ? 0.85 : (isElegant ? 0.25 : 0.04);
        if (isOwned && isNight && ownerTheme) {
          mesh.material[idx].emissive.setStyle(ownerTheme.colorHex);
          mesh.material[idx].emissiveIntensity = 0.50;
        } else if (isOwned && isSunset && ownerTheme) {
          mesh.material[idx].emissive.setStyle(ownerTheme.colorHex);
          mesh.material[idx].emissiveIntensity = 0.25;
        } else {
          mesh.material[idx].emissive.setHex(0x000000);
          mesh.material[idx].emissiveIntensity = 0;
        }
        mesh.material[idx].needsUpdate = true;
      }
    });
  }

  const frame = context.tileBorderFrames[tileId];
  if (frame && frame.userData?.borderMat) {
    if (isOwned && ownerTheme) {
      frame.visible = true;
      frame.userData.borderMat.color.setStyle(ownerTheme.colorHex);
      frame.userData.borderMat.emissive.setStyle(ownerTheme.colorHex);
      if (isNight) {
        frame.userData.borderMat.emissiveIntensity = 0.85;
      } else if (isSunset) {
        frame.userData.borderMat.emissiveIntensity = 0.50;
      } else {
        frame.userData.borderMat.emissiveIntensity = 0.28;
      }
    } else {
      frame.visible = false;
      frame.userData.borderMat.emissiveIntensity = 0;
    }
  }

  const pool = context.tileGroundLightPools[tileId];
  if (pool && pool.material) {
    if (isOwned && ownerTheme) {
      pool.visible = true;
      pool.material.color.setStyle(ownerTheme.colorHex);
      pool.material.opacity = isNight ? 0.45 : (isSunset ? 0.35 : 0.25);
    } else {
      pool.visible = false;
      pool.material.opacity = 0;
    }
  }

  if ([0, 8, 16, 24].includes(tileId)) return;

  const bGroup = context.tileBuildingGroups[tileId];
  if (!bGroup) return;
  while (bGroup.children.length > 0) {
    const child = bGroup.children[0];
    disposeHierarchy(child);
    bGroup.remove(child);
  }
  if (!propState || propState.owner === null || propState.mortgaged) return;

  const pos = getTileWorldPosition(tileId);
  if (pos.side === 1) bGroup.rotation.y = -Math.PI / 2;
  else if (pos.side === 2) bGroup.rotation.y = Math.PI;
  else if (pos.side === 3) bGroup.rotation.y = Math.PI / 2;
  else bGroup.rotation.y = 0;

  const ownerColor = PLAYER_THEMES[propState.owner]?.charColor ?? 0x6366f1;
  const lvl = propState.level || 0;

  if (lvl === 0) {
    const flagMesh = createDetailedFlagMesh(ownerColor);
    // Position flag in corner sidewalk so it never occludes card text
    flagMesh.position.set(0.95, 0, -0.92);
    flagMesh.scale.set(0.01, 0.01, 0.01);
    bGroup.add(flagMesh);
    animatedBuildingPopups.push({ mesh: flagMesh, startTime: performance.now(), duration: 400 });
  } else if (lvl >= 1 && lvl <= 3) {
    const hGroup = createDetailedHouseMesh(ownerColor, lvl);
    hGroup.position.set(0, 0, -0.88);
    hGroup.scale.set(0.01, 0.01, 0.01);
    bGroup.add(hGroup);
    animatedBuildingPopups.push({ mesh: hGroup, startTime: performance.now(), duration: 420 });
  } else if (lvl >= 4) {
    const towerGroup = createDetailedSkyscraperMesh(ownerColor);
    towerGroup.position.set(0, 0, -0.85);
    towerGroup.scale.set(0.01, 0.01, 0.01);
    bGroup.add(towerGroup);
    animatedBuildingPopups.push({ mesh: towerGroup, startTime: performance.now(), duration: 500 });
  }
}

export const updateTileMesh = refreshTileTextureAndBuildings;

/**
 * Refreshes textures, side colors, and materials on all 32 tiles simultaneously.
 */
export function refreshAllTileTexturesAndMaterials() {
  BOARD_TILES.forEach(tile => {
    refreshTileTextureAndBuildings(tile.id);
  });
  updateDioramaCenterForEdition(matchSettings?.boardEdition || 'world');
}
