#!/bin/bash
# ========================================================================
#  World Tycoon: Global Edition - macOS Double-Click Terminal Launcher
# ========================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ -f "$SCRIPT_DIR/WorldTycoon.app/Contents/MacOS/WorldTycoon" ]; then
    exec "$SCRIPT_DIR/WorldTycoon.app/Contents/MacOS/WorldTycoon"
fi

GAME_DIR="$SCRIPT_DIR/world-tycoon"
if [ ! -d "$GAME_DIR" ]; then
    GAME_DIR="$SCRIPT_DIR"
fi

PORT=3000
for p in $(seq 3000 3050); do
    if ! lsof -i :$p >/dev/null 2>&1; then
        PORT=$p
        break
    fi
done

URL="http://localhost:$PORT"

echo "=========================================================="
echo "   WORLD TYCOON: GLOBAL EDITION (3D WEBRTC MULTIPLAYER)   "
echo "=========================================================="
echo "[+] Starting local server on port $PORT..."
echo "[+] Game URL: $URL"
echo "=========================================================="

cd "$GAME_DIR"

if command -v python3 >/dev/null 2>&1; then
    python3 -m http.server "$PORT" &
    SERVER_PID=$!
elif command -v python >/dev/null 2>&1; then
    python -m SimpleHTTPServer "$PORT" &
    SERVER_PID=$!
else
    echo "Python 3 or Node is required."
    exit 1
fi

cleanup() {
    if [ -n "$SERVER_PID" ]; then
        kill "$SERVER_PID" 2>/dev/null || true
    fi
    exit 0
}
trap cleanup INT TERM EXIT

sleep 0.8
open "$URL"

echo "[+] Game opened in your browser!"
echo "[+] Press Ctrl+C in this terminal when finished playing."
echo ""

wait "$SERVER_PID"
